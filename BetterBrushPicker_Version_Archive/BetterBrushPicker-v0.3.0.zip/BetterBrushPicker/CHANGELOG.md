# Better Brush Picker Changelog

## 0.3.0 — Reliability foundation

- Preserved the v0.2.9 direct tile-enumeration and persistent per-tileset cache architecture.
- Added centralized `validateTileForBrush()` validation for selectable tile IDs, textures, and sprites.
- Added centralized `selectTile()` handling for `ISBrushToolTileCursor` creation and `getCell():setDrag()`.
- Moved search-result construction into `BetterBrushPicker.buildSearchResults()`.
- Reset the selected result when search text or category changes.
- Refreshes the UI when all tilesets are loaded entirely from cache.
- Reduced routine cache logging; verbose cache messages now require `BetterBrushPicker.DEBUG = true`.
- Kept the v0.2.9 no-global-sort behavior and 128-ID scan burst.
- Cache format remains `BBP_CACHE_7`; no cache invalidation is required solely for this release.

## 0.2.9 — Performance baseline

- Reduced indexing burst size to 128 actual tile IDs per tick.
- Removed the final global sort of the full index.
- Removed the second full sort of the search results.
- Preserved persistent per-tileset caching.

## 0.2.8

- Tightened direct enumeration to Brush Tool-compatible numeric atlas IDs (0-2047).
- Added defensive validation before creating the vanilla brush cursor.
- Advanced the cache format for the stricter tile filter.

## Earlier builds

Earlier experimental builds are preserved in the historical archive under `versions/` so regressions can be traced to the exact source snapshot that introduced them.
