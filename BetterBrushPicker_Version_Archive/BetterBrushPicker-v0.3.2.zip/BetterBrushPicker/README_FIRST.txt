Better Brush Picker
Author: Dizzy
Steam: https://steamcommunity.com/id/illMindOfDizzy/

BETTER BRUSH PICKER — BUILD 42
Version 0.3.2

WHAT THIS VERSION DOES
- Replaces the vanilla Brush Tool tile picker window.
- Builds an index of individual tiles/sprites instead of requiring a tilesheet first.
- Shows visual tile results in a scrollable grid.
- Searches individual tile IDs plus tileset names, categories, and semantic aliases.
- Includes broad aliases for common searches such as chair, fridge, window, door, wall, table, bed, toilet, sink, etc.
- Keeps the vanilla ISBrushToolTileCursor for actual tile placement/dragging.
- Adds category filters.
- The tile index is built gradually after the game starts to avoid a large one-time freeze.

V0.3.2 UI/HITBOX POLISH
- Fixes card drawing and mouse hit-testing to use the same scroll coordinates.
- Adds spacing between cards so neighboring previews and borders do not overlap.
- Constrains every preview to a dedicated box and clamps unusual texture offsets.
- Keeps long tile IDs and tileset names inside their card by trimming them to the available width.
- Adds a hover outline showing exactly which card will be clicked.

V0.3.0 RELIABILITY FOUNDATION
- Keeps the v0.2.9 direct-enumeration and persistent-cache architecture intact.
- Centralizes tile validation before brush-cursor creation.
- Centralizes vanilla brush-cursor selection and drag activation in one guarded function.
- Moves search-result construction into the BetterBrushPicker data layer instead of embedding it in the window code.
- Clears the selected result when search text or category changes.
- Reduces routine per-tileset cache logging unless DEBUG is enabled.
- Refreshes the picker when every tileset is loaded directly from cache.
- Keeps the no-global-sort behavior from v0.2.9.

PERSISTENT DIRECT CACHE
- The full available Brush Tool-compatible tile catalog is indexed.
- The scanner uses IsoWorld:getAllTilesName() plus IsoWorld:getAllTiles(filename) to enumerate actual tile IDs exposed by Build 42 instead of probing thousands of possible numeric slots.
- Scanning happens in bursts of up to 128 actual tile IDs per game tick.
- Each completed tileset is written to its own persistent cache file in the Project Zomboid user-data area.
- Cached tilesets are loaded on later launches instead of being rescanned.
- If the game crashes or closes during a scan, completed tilesets remain cached and the next launch resumes with the missing tilesets.
- Cache files use the BBP_CACHE_7 header. Only Brush Tool atlas-style IDs in the form <tileset>_<numeric index> with indices 0-2047 are accepted.

INSTALLATION (MAC)
1. Quit Project Zomboid.
2. Put the BetterBrushPicker folder directly in:
   ~/Zomboid/mods/
3. Enable Better Brush Picker in the Mods menu.
4. Start/load your world.
5. Open Debug -> Brush Tool -> Choose tile.
6. The window should say:
   Better Brush Picker — Individual Tiles

IMPORTANT
- Do NOT put the ZIP file itself in ~/Zomboid/mods/.
- Keep this folder named BetterBrushPicker.
- Keep the 42/ folder structure intact.
- Remove/replace older Better Brush Picker copies so that only the intended version is enabled.

DEBUGGING
- DEBUG logging is disabled by default.
- If a selection is refused, the log reports the reason instead of allowing an invalid tile through to the vanilla cursor.
- If the game reports a Lua error or crash, quit the game and send the relevant portion of:
  ~/Zomboid/console.txt

Do not delete working cache files unless a future release specifically asks you to clear them.
