-- Better Brush Picker
-- Build 42
-- Version 0.5.0
-- Author: Dizzy
--
-- v0.2.8 replaces the old fixed-slot probing scan with direct enumeration of the tiles exposed by IsoWorld:getAllTiles. Persistent per-definition-list caching is kept.
-- v0.2.9 avoids full-index and full-result sorting so completion does not block the game thread on ~61k entries.
-- v0.3.0 keeps that indexing path intact and makes tile filtering/selection use centralized, guarded functions.
-- v0.3.1 fixes tile-grid scrolling/hitbox alignment and gives each tile card
-- dedicated spacing and bounded text so labels and clickable areas do not overlap.
-- v0.3.2 clamps custom scrolling to the real content bounds and derives visible
-- rows from the viewport so scrolling cannot move into an empty/black region.
-- v0.3.3 overrides the inherited Brush Tool list stencil so the custom grid
-- uses its full live viewport instead of the vanilla list clip region.
-- v0.4.0 adds persistent Favorites and Recent tile lists without changing the
-- underlying index/cache format or vanilla brush-cursor selection path.
-- v0.4.1 is a diagnostic build that logs the tile-grid viewport, scroll metrics,
-- parent geometry, scrollbar geometry, and calculated visible rows so the remaining
-- rendering/clipping problem can be isolated without changing the index itself.
-- v0.4.2 stops deriving the custom grid from BrushToolTilePickerList. The custom
-- grid now derives directly from ISPanel so the vanilla picker cannot impose hidden
-- list rendering/scroll state on the custom grid.
-- v0.4.3 incrementally warms tilesets, but sheet_0 is not guaranteed to be a
-- valid representative sprite for every definition list.
-- v0.4.4 resolves thumbnails through both direct texture lookup and the loaded
-- IsoSprite animation frame, and warms each definition using its actual first
-- brush-compatible tile ID instead of assuming an _0 entry exists.
-- v0.4.5 improves tile-card visibility with white card/preview outlines and
-- uses one explicit version marker for startup logging.
-- v0.5.0 rebuilds the visual picker around Project Zomboid's native
-- ISScrollingListBox. Tiles are grouped into compact rows of eight, so the
-- vanilla UI system owns clipping and scrolling instead of a custom stencil.
-- Thumbnail lookup uses the same getTexture(tileId) path as the vanilla tile
-- picker, with a lazy sprite materialization fallback only for visible tiles.
-- The proven direct tile enumeration and persistent cache are retained.
-- The picker no longer requires the
-- user to choose a tilesheet before browsing results. Search results are
-- individual sprite/tile IDs and selection still uses the vanilla
-- ISBrushToolTileCursor.

local BetterBrushPicker = {}
BetterBrushPicker.DEBUG = false
BetterBrushPicker.DIAGNOSTIC = false
BetterBrushPicker.textureWarmup = { queue = {}, index = 1, attempted = 0, loaded = 0, ready = false }
BetterBrushPicker.thumbnailTextureCache = {}
BetterBrushPicker.thumbnailStats = { direct = 0, spriteFrame = 0, reloaded = 0, missing = 0, logged = 0 }
BetterBrushPicker.thumbnailLoggedIds = {}
BetterBrushPicker.installed = false
BetterBrushPicker.indexReady = false
BetterBrushPicker.indexBuilding = false
BetterBrushPicker.index = {}
BetterBrushPicker.indexById = {}
BetterBrushPicker.tilesets = {}
BetterBrushPicker.activeCategory = "All"
BetterBrushPicker.viewMode = "All"
BetterBrushPicker.lastSearch = ""
BetterBrushPicker.indexState = nil
BetterBrushPicker.favorites = {}
BetterBrushPicker.favoriteOrder = {}
BetterBrushPicker.recentOrder = {}
BetterBrushPicker.userStateLoaded = false

-- Persistent cache and incremental work settings.
local CACHE_PREFIX = "BetterBrushPicker_tileset_"
local USER_STATE_FILE = "BetterBrushPicker_user_state.txt"
local MAX_RECENT = 50
local TILES_PER_BURST = 128
local TEXTURES_PER_WARMUP_TICK = 4

BetterBrushPicker.categories = {
    "All", "Furniture", "Walls", "Floors", "Decor", "Doors", "Windows", "Plants", "Roofs", "Other"
}

-- These aliases are deliberately broad. They supplement the actual sprite
-- and tileset names and will be refined in later versions with more exact
-- per-sprite semantic tagging.
BetterBrushPicker.aliases = {
    chair = "chair chairs seat seating stool bench furniture",
    couch = "couch sofa sofas loveseat seating furniture",
    sofa = "sofa sofas couch couches loveseat seating furniture",
    table = "table tables desk furniture",
    desk = "desk desks table furniture office",
    bed = "bed beds bedding furniture",
    dresser = "dresser dressers storage furniture",
    shelf = "shelf shelves shelving storage furniture",
    cabinet = "cabinet cabinets cupboard storage furniture",
    locker = "locker lockers storage",
    fridge = "fridge refrigerator refrigeration freezer appliance appliances",
    refrigerator = "fridge refrigerator refrigeration freezer appliance appliances",
    freezer = "fridge refrigerator refrigeration freezer appliance appliances",
    stove = "stove cooker oven cooking appliance appliances",
    oven = "oven stove cooker cooking appliance appliances",
    microwave = "microwave appliance appliances cooking",
    sink = "sink sinks bathroom plumbing fixture fixtures counter",
    toilet = "toilet toilets bathroom plumbing fixture fixtures",
    bathtub = "bathtub tub bathroom plumbing fixture fixtures",
    shower = "shower bathroom plumbing fixture fixtures",
    window = "window windows curtain curtains fixture fixtures",
    door = "door doors doorway frame gate fixture fixtures",
    wall = "wall walls brick wood stone clapboard fence fencing railing",
    floor = "floor floors ground street road sidewalk curb carpet wood tile stone gravel dirt grass",
    plant = "plant plants tree trees bush bushes flower flowers vine vines vegetation foliage",
    tree = "tree trees vegetation foliage",
    grass = "grass vegetation foliage floor",
    roof = "roof roofs snow roofcap",
    lamp = "lamp lighting light lights fixture fixtures",
    light = "lamp lighting light lights fixture fixtures",
    rug = "rug rugs carpet carpets floor",
    sign = "sign signs signage notice notices poster advertising",
}

local function log(message)
    print("[BetterBrushPicker] " .. tostring(message))
end

local function debugLog(message)
    if BetterBrushPicker.DEBUG then
        print("[BetterBrushPicker][DEBUG] " .. tostring(message))
    end
end

local function diagnosticLog(message)
    if BetterBrushPicker.DIAGNOSTIC then
        print("[BetterBrushPicker][DIAG] " .. tostring(message))
    end
end

local function lower(value)
    return string.lower(tostring(value or ""))
end

local function contains(text, needle)
    return string.find(lower(text), lower(needle), 1, true) ~= nil
end

local function categoryFor(name)
    local n = lower(name)
    if contains(n, "door") or contains(n, "gate") then return "Doors" end
    if contains(n, "window") then return "Windows" end
    if contains(n, "roof") then return "Roofs" end
    if contains(n, "floor") or contains(n, "street") or contains(n, "curb") or contains(n, "blend") then return "Floors" end
    if contains(n, "wall") or contains(n, "fenc") or contains(n, "rail") then return "Walls" end
    if contains(n, "furniture") or contains(n, "appliance") or contains(n, "seating") or contains(n, "shelving")
        or contains(n, "storage") or contains(n, "counter") or contains(n, "sink") or contains(n, "bathroom")
        or contains(n, "bedding") or contains(n, "table") or contains(n, "desks") then return "Furniture" end
    if contains(n, "tree") or contains(n, "bush") or contains(n, "flower") or contains(n, "plant")
        or contains(n, "vegetation") or contains(n, "foliage") then return "Plants" end
    if contains(n, "sign") or contains(n, "notice") or contains(n, "overlay") or contains(n, "graffiti")
        or contains(n, "grime") or contains(n, "trash") or contains(n, "junk") or contains(n, "lighting")
        or contains(n, "light") or contains(n, "curtain") or contains(n, "rug") then return "Decor" end
    return "Other"
end

local function tileBaseName(fullName)
    local s = tostring(fullName or "")
    local base = s:match("^([^%.]+)")
    return base or s
end

local function isBrushTileId(tileName)
    local s = tostring(tileName or "")
    if s == "" then return false end
    local numericIndex = tonumber(s:match("_(%d+)$"))
    if numericIndex == nil then return false end
    return numericIndex >= 0 and numericIndex <= 2047
end

local function splitSearch(text)
    local tokens = {}
    for token in lower(text):gmatch("%S+") do
        table.insert(tokens, token)
    end
    return tokens
end

local function matchesTokens(searchText, tokens)
    if #tokens == 0 then return true end

    local text = lower(searchText)
    for i = 1, #tokens do
        local token = lower(tokens[i])
        local matched = string.find(text, token, 1, true) ~= nil

        if not matched then
            local aliasText = BetterBrushPicker.aliases[token]
            if aliasText ~= nil then
                for aliasToken in lower(aliasText):gmatch("%S+") do
                    if string.find(text, aliasToken, 1, true) ~= nil then
                        matched = true
                        break
                    end
                end
            end
        end

        if not matched then return false end
    end

    return true
end

local function buildSearchText(tileName, tilesetName, category, parent, spriteType)
    local text = lower(tostring(tileName or "") .. " " .. tostring(tilesetName or "") .. " " .. tostring(category or "") .. " " .. tostring(parent or "") .. " " .. tostring(spriteType or ""))

    -- Add semantic aliases based on the actual tileset name. These aliases
    -- improve searches such as "chair", "fridge", and "window" while each
    -- result remains the individual tile ID.
    local n = lower(tilesetName)
    if contains(n, "seating") then text = text .. " chair chairs seat seating stool bench couch sofa loveseat " end
    if contains(n, "bedding") then text = text .. " bed beds mattress bedding " end
    if contains(n, "refriger") then text = text .. " fridge refrigerator freezer appliance " end
    if contains(n, "cooking") then text = text .. " stove oven cooker microwave cooking appliance " end
    if contains(n, "bathroom") then text = text .. " toilet sink bathtub tub shower bathroom plumbing fixture " end
    if contains(n, "windows") then text = text .. " window windows curtain curtains " end
    if contains(n, "doors") then text = text .. " door doors doorway frame gate " end
    if contains(n, "tables") then text = text .. " table tables desk " end
    if contains(n, "shelving") then text = text .. " shelf shelves shelving storage " end
    if contains(n, "storage") then text = text .. " cabinet cupboard locker storage " end
    if contains(n, "lighting") then text = text .. " lamp light lighting fixture " end
    if contains(n, "plants") or contains(n, "vegetation") then text = text .. " plant tree bush flower vine vegetation foliage " end

    return text
end

local function uniqueTilesets()
    local result = {}
    local seen = {}
    local world = getWorld()

    -- Prefer the same definition-name list used by B42's direct tile API.
    local namesOk, names = pcall(function() return world:getAllTilesName() end)
    if namesOk and names ~= nil then
        for i = 0, names:size() - 1 do
            local imageName = tostring(names:get(i))
            local base = imageName:match("^([^%.]+)") or imageName
            if base ~= "" and not seen[base] then
                seen[base] = true
                table.insert(result, base)
            end
        end
    end

    -- Fallback only if the direct definition-name API returns nothing.
    if #result == 0 then
        local images = world:getTileImageNames()
        if images == nil then return result end
        for i = 0, images:size() - 1 do
            local imageName = tostring(images:get(i))
            local base = imageName:match("^([^%.]+)") or imageName
            if base ~= "" and not seen[base] then
                seen[base] = true
                table.insert(result, base)
            end
        end
    end

    table.sort(result)
    return result
end

-- Build a direct queue from B42's actual tile-definition lists.
-- IMPORTANT: getAllTiles() returns a Java HashMap, but its keySet()/iterator()
-- methods are not exposed to Kahlua reliably in the target B42 build. The
-- public getAllTilesName() + getAllTiles(filename) route is safer here.
local function getTileDefinitionNames(world)
    local ok, names = pcall(function() return world:getAllTilesName() end)
    if not ok or names == nil then
        return nil, "IsoWorld:getAllTilesName() failed"
    end
    local sizeOk, size = pcall(function() return names:size() end)
    if not sizeOk or size == nil then
        return nil, "IsoWorld:getAllTilesName() returned an unusable list"
    end
    return names, nil
end

local function buildDirectTileLookup()
    local world = getWorld()
    local names, namesError = getTileDefinitionNames(world)
    if names == nil then
        log("ERROR: " .. tostring(namesError))
        return nil, 0, 0
    end

    local queue = {}
    local seen = {}
    local totalDirectIds = 0
    local failedSets = 0
    local definitionCount = names:size()

    for i = 0, definitionCount - 1 do
        local nameOk, filename = pcall(function() return tostring(names:get(i)) end)
        if nameOk and filename ~= nil and filename ~= "" and filename ~= "nil" then
            -- Keep the exact filename returned by B42. Do not strip its
            -- extension before calling getAllTiles(filename).
            local tileset = tileBaseName(filename)
            if tileset ~= "" and not seen[tileset] then
                local listOk, tileList = pcall(function()
                    return world:getAllTiles(filename)
                end)

                -- Defensive fallback for builds where the list is keyed by
                -- the base name rather than the definition filename.
                if (not listOk or tileList == nil) and tileset ~= filename then
                    listOk, tileList = pcall(function()
                        return world:getAllTiles(tileset)
                    end)
                end

                local count = 0
                if listOk and tileList ~= nil then
                    local sizeOk, size = pcall(function() return tileList:size() end)
                    if sizeOk and size ~= nil then
                        count = size
                    else
                        listOk = false
                    end
                end

                seen[tileset] = true
                if listOk and tileList ~= nil then
                    table.insert(queue, {
                        tileset = tileset,
                        filename = filename,
                        tiles = tileList,
                        count = count,
                    })
                    totalDirectIds = totalDirectIds + count
                else
                    failedSets = failedSets + 1
                    print(string.format("[BetterBrushPicker] WARNING: could not enumerate tile IDs for %s", filename))
                end
            end
        end
    end

    log(string.format(
        "Direct tile enumeration found %d actual tile IDs across %d tilesets (%d definition lists failed).",
        totalDirectIds, #queue, failedSets
    ))
    return queue, totalDirectIds, failedSets
end

local function sanitizeFilePart(value)
    local s = tostring(value or "")
    s = s:gsub("[^%w%._%-]", "_")
    if s == "" then s = "unknown" end
    return s
end

local function cacheFileFor(definitionFilename)
    return CACHE_PREFIX .. sanitizeFilePart(definitionFilename) .. ".txt"
end

local function writeLine(writer, value)
    writer:write(tostring(value or "") .. "\n")
end

local function arrayContains(array, value)
    for i = 1, #array do
        if array[i] == value then return true end
    end
    return false
end

local function removeFromArray(array, value)
    for i = #array, 1, -1 do
        if array[i] == value then
            table.remove(array, i)
        end
    end
end

local function loadUserState()
    if BetterBrushPicker.userStateLoaded then return end
    BetterBrushPicker.userStateLoaded = true

    local reader = getFileReader(USER_STATE_FILE, false)
    if not reader then return end

    local line = reader:readLine()
    if line ~= "BBP_USER_STATE_1" then
        reader:close()
        return
    end

    while true do
        line = reader:readLine()
        if line == nil or line == "END" then break end

        local kind, id = line:match("^([^|]+)|(.+)$")
        if kind == "FAV" and id ~= nil and isBrushTileId(id) then
            if not BetterBrushPicker.favorites[id] then
                BetterBrushPicker.favorites[id] = true
                table.insert(BetterBrushPicker.favoriteOrder, id)
            end
        elseif kind == "REC" and id ~= nil and isBrushTileId(id) then
            if not arrayContains(BetterBrushPicker.recentOrder, id) then
                table.insert(BetterBrushPicker.recentOrder, id)
            end
        end
    end

    reader:close()

    while #BetterBrushPicker.recentOrder > MAX_RECENT do
        table.remove(BetterBrushPicker.recentOrder)
    end

    debugLog(string.format("Loaded user state: %d favorites, %d recent tiles.",
        #BetterBrushPicker.favoriteOrder, #BetterBrushPicker.recentOrder))
end

local function saveUserState()
    local writer = getFileWriter(USER_STATE_FILE, true, false)
    if not writer then
        log("WARNING: could not save favorites/recent tile state.")
        return false
    end

    writeLine(writer, "BBP_USER_STATE_1")

    for i = 1, #BetterBrushPicker.favoriteOrder do
        local id = BetterBrushPicker.favoriteOrder[i]
        if BetterBrushPicker.favorites[id] then
            writeLine(writer, "FAV|" .. id)
        end
    end

    for i = 1, #BetterBrushPicker.recentOrder do
        writeLine(writer, "REC|" .. BetterBrushPicker.recentOrder[i])
    end

    writeLine(writer, "END")
    writer:close()
    return true
end

function BetterBrushPicker.isFavorite(tileName)
    loadUserState()
    return BetterBrushPicker.favorites[tostring(tileName or "")] == true
end

function BetterBrushPicker.toggleFavorite(tileName)
    local id = tostring(tileName or "")
    if id == "" or not isBrushTileId(id) then return false end
    loadUserState()

    if BetterBrushPicker.favorites[id] then
        BetterBrushPicker.favorites[id] = nil
        removeFromArray(BetterBrushPicker.favoriteOrder, id)
    else
        BetterBrushPicker.favorites[id] = true
        table.insert(BetterBrushPicker.favoriteOrder, id)
    end

    saveUserState()
    if BrushToolChooseTileUI ~= nil and BrushToolChooseTileUI.instance ~= nil then
        BrushToolChooseTileUI.instance:refreshResults()
    end
    return true
end

function BetterBrushPicker.addRecent(tileName)
    local id = tostring(tileName or "")
    if id == "" or not isBrushTileId(id) then return end
    loadUserState()

    local wasFirst = BetterBrushPicker.recentOrder[1] == id
    removeFromArray(BetterBrushPicker.recentOrder, id)
    table.insert(BetterBrushPicker.recentOrder, 1, id)
    while #BetterBrushPicker.recentOrder > MAX_RECENT do
        table.remove(BetterBrushPicker.recentOrder)
    end

    if not wasFirst then
        saveUserState()
    end
end

local function resolveTileTexture(tileName)
    local id = tostring(tileName or "")
    if id == "" then return nil end

    local cached = BetterBrushPicker.thumbnailTextureCache[id]
    if cached ~= nil then
        return cached
    end

    -- This is the same texture lookup used by the vanilla B42 tile picker.
    local ok, texture = pcall(function()
        return getTexture(id)
    end)
    if ok and texture ~= nil then
        BetterBrushPicker.thumbnailTextureCache[id] = texture
        BetterBrushPicker.thumbnailStats.direct = BetterBrushPicker.thumbnailStats.direct + 1
        return texture
    end

    -- Some registered tile sprites do not materialize their texture until the
    -- sprite is explicitly asked to load its no-direction frame. Do that only
    -- for a tile that is actually being drawn; never bulk-warm all 61k tiles.
    local spriteOk, sprite = pcall(function() return getSprite(id) end)
    if spriteOk and sprite ~= nil then
        local loaded = pcall(function()
            sprite:LoadFramesNoDirPageSimple(id)
        end)
        if loaded then
            local retryOk, retryTexture = pcall(function()
                return getTexture(id)
            end)
            if retryOk and retryTexture ~= nil then
                BetterBrushPicker.thumbnailTextureCache[id] = retryTexture
                BetterBrushPicker.thumbnailStats.reloaded = BetterBrushPicker.thumbnailStats.reloaded + 1
                if BetterBrushPicker.thumbnailStats.logged < 16 then
                    BetterBrushPicker.thumbnailStats.logged = BetterBrushPicker.thumbnailStats.logged + 1
                    log("Thumbnail loaded lazily: " .. id)
                end
                return retryTexture
            end
        end
    end

    BetterBrushPicker.thumbnailStats.missing = BetterBrushPicker.thumbnailStats.missing + 1
    if BetterBrushPicker.thumbnailStats.logged < 24 and not BetterBrushPicker.thumbnailLoggedIds[id] then
        BetterBrushPicker.thumbnailLoggedIds[id] = true
        BetterBrushPicker.thumbnailStats.logged = BetterBrushPicker.thumbnailStats.logged + 1
        log("Thumbnail unavailable: " .. id)
    end
    return nil
end

local function readCacheFile(fileName)
    local reader = getFileReader(fileName, false)
    if not reader then return nil end

    local rows = {}
    local line = reader:readLine()
    if line ~= "BBP_CACHE_7" then
        reader:close()
        return nil
    end

    line = reader:readLine()
    while line ~= nil do
        if line == "END" then
            reader:close()
            return rows
        end
        local id, tileset, category = line:match("^([^|]*)|([^|]*)|([^|]*)$")
        if id and tileset and category and isBrushTileId(id) then
            table.insert(rows, {
                id = id,
                name = id,
                tileset = tileset,
                category = category,
                parent = "",
                spriteType = "",
                searchText = buildSearchText(id, tileset, category, "", ""),
            })
        else
            reader:close()
            return nil
        end
        line = reader:readLine()
    end

    reader:close()
    return nil
end

local function writeCacheFile(tileset, definitionFilename, rows)
    local fileName = cacheFileFor(definitionFilename or tileset)
    local writer = getFileWriter(fileName, true, false)
    if not writer then return false end

    writeLine(writer, "BBP_CACHE_7")
    for i = 1, #rows do
        local result = rows[i]
        writeLine(writer, result.id .. "|" .. result.tileset .. "|" .. result.category)
    end
    writeLine(writer, "END")
    writer:close()
    return true
end


local function loadExistingCacheSets(tilesetQueue, failedDefinitions)
    local loaded = {}
    local missing = {}
    local cachedSets = 0

    for i = 1, #tilesetQueue do
        local entry = tilesetQueue[i]
        local tileset = entry.tileset
        local rows = readCacheFile(cacheFileFor(entry.filename or tileset))
        if rows then
            for j = 1, #rows do
                table.insert(loaded, rows[j])
                BetterBrushPicker.indexById[rows[j].id] = rows[j]
            end
            cachedSets = cachedSets + 1
        else
            table.insert(missing, entry)
        end
    end

    BetterBrushPicker.index = loaded
    BetterBrushPicker.tilesets = missing
    BetterBrushPicker.indexState = {
        tilesetIndex = 1,
        tileIndex = 0,
        added = #loaded,
        checked = 0,
        cached = cachedSets,
        totalTilesets = #tilesetQueue,
        totalActualTiles = 0,
        missingTilesets = 0,
        failedDefinitions = failedDefinitions or 0,
    }

    for i = 1, #missing do
        local count = missing[i].count or 0
        BetterBrushPicker.indexState.totalActualTiles = BetterBrushPicker.indexState.totalActualTiles + count
        if count == 0 then BetterBrushPicker.indexState.missingTilesets = BetterBrushPicker.indexState.missingTilesets + 1 end
    end

    if cachedSets > 0 then
        log(string.format("Loaded %d cached tilesets (%d tiles); %d tilesets remain for direct enumeration.", cachedSets, #loaded, #missing))
    end

    return cachedSets > 0 or #missing == 0
end

local function finishIndex()
    local state = BetterBrushPicker.indexState
    BetterBrushPicker.indexBuilding = false
    BetterBrushPicker.indexReady = true
    log(string.format("Full index ready: %d individual tiles checked=%d; cached sets=%d (no final global sort).",
        state and state.added or #BetterBrushPicker.index,
        state and state.checked or 0,
        state and state.cached or 0))

    if BrushToolChooseTileUI ~= nil and BrushToolChooseTileUI.instance ~= nil then
        BrushToolChooseTileUI.instance:refreshResults()
    end
end

function BetterBrushPicker.startIndexBuild()
    if BetterBrushPicker.indexBuilding or BetterBrushPicker.indexReady then return end

    local allTilesets = uniqueTilesets()
    local tileQueue, directTotal, failedSets = buildDirectTileLookup()
    BetterBrushPicker.index = {}
    BetterBrushPicker.indexById = {}
    BetterBrushPicker.tilesets = {}

    if tileQueue == nil then
        tileQueue = {}
    end

    loadExistingCacheSets(tileQueue, failedSets)

    if (#tileQueue == 0 or directTotal == 0) and #allTilesets > 0 then
        BetterBrushPicker.indexBuilding = false
        BetterBrushPicker.indexReady = false
        BetterBrushPicker.indexState.error = "B42 did not return usable tile IDs through IsoWorld:getAllTiles(filename)"
        log("ERROR: direct tile enumeration returned zero usable IDs. Scan stopped; no empty caches were intentionally generated.")
        return
    end

    if #BetterBrushPicker.tilesets == 0 then
        BetterBrushPicker.indexReady = true
        BetterBrushPicker.indexBuilding = false
        BetterBrushPicker.indexState.cached = #allTilesets
        BetterBrushPicker.indexState.totalTilesets = #allTilesets
        log(string.format("All %d tilesets loaded from persistent cache.", #allTilesets))
        if BrushToolChooseTileUI ~= nil and BrushToolChooseTileUI.instance ~= nil then
            BrushToolChooseTileUI.instance:refreshResults()
        end
        return
    end

    BetterBrushPicker.indexBuilding = true
    BetterBrushPicker.indexReady = false
    log(string.format("Direct index build/resume: %d tilesets remaining, %d actual tile IDs per burst.", #BetterBrushPicker.tilesets, TILES_PER_BURST))

    if (BetterBrushPicker.indexState.failedDefinitions or 0) > 0 then
        log(string.format("WARNING: %d definition lists could not be enumerated and were skipped; no empty cache was written for them.", BetterBrushPicker.indexState.failedDefinitions))
    end
end

function BetterBrushPicker.tickIndexBuild()
    local state = BetterBrushPicker.indexState
    if not BetterBrushPicker.indexBuilding or state == nil then return end

    local budget = TILES_PER_BURST
    while budget > 0 and state.tilesetIndex <= #BetterBrushPicker.tilesets do
        local entry = BetterBrushPicker.tilesets[state.tilesetIndex]
        local tileset = entry.tileset
        local tileList = entry.tiles
        local tileCount = entry.count or 0

        if tileList == nil or state.tileIndex >= tileCount then
            local rows = {}
            local prefix = tileset .. "_"
            for i = #BetterBrushPicker.index, 1, -1 do
                local result = BetterBrushPicker.index[i]
                if string.sub(result.id, 1, #prefix) == prefix then
                    table.insert(rows, 1, result)
                else
                    break
                end
            end

            if writeCacheFile(tileset, entry.filename, rows) then
                state.cached = (state.cached or 0) + 1
                debugLog(string.format("Cached tileset %s (%s): %d tiles.", tileset, tostring(entry.filename or ""), #rows))
            else
                log("WARNING: could not write cache for " .. tostring(entry.filename or tileset))
            end

            if tileCount == 0 then
                log("WARNING: no direct tile IDs reported for " .. tileset)
            end

            state.tileIndex = 0
            state.tilesetIndex = state.tilesetIndex + 1
            -- Yield after each completed tileset.
            break
        end

        local ok, tileName = pcall(function()
            return tostring(tileList:get(state.tileIndex))
        end)
        state.tileIndex = state.tileIndex + 1
        state.checked = state.checked + 1
        budget = budget - 1

        if ok and tileName ~= nil and tileName ~= "nil" and tileName ~= "" and isBrushTileId(tileName) then
            local category = categoryFor(tileset)
            local result = {
                id = tileName,
                name = tileName,
                tileset = tileset,
                category = category,
                parent = "",
                spriteType = "",
                searchText = buildSearchText(tileName, tileset, category, "", ""),
            }
            table.insert(BetterBrushPicker.index, result)
            BetterBrushPicker.indexById[tileName] = result
            state.added = state.added + 1
        end
    end

    if state.tilesetIndex > #BetterBrushPicker.tilesets then
        finishIndex()
    end
end

local BetterBrushPickerTileRowList = nil

local function diagnosticGridState(list, label)
    if not BetterBrushPicker.DIAGNOSTIC or list == nil then return end

    local width = tonumber(list.width) or -1
    local height = tonumber(list.height) or -1
    local yScroll = -1
    local scrollHeight = -1
    pcall(function() yScroll = tonumber(list:getYScroll()) or -1 end)
    pcall(function() scrollHeight = tonumber(list:getScrollHeight()) or -1 end)

    local signature = table.concat({
        tostring(label or ""), tostring(width), tostring(height),
        tostring(#(list.items or {})), tostring(yScroll), tostring(scrollHeight),
        tostring(list.selected or -1), tostring(list.mouseoverselected or -1)
    }, "|")

    if list._bbpDiagnosticLast ~= signature then
        list._bbpDiagnosticLast = signature
        diagnosticLog(string.format(
            "%s | list=%dx%d rows=%d yScroll=%d scrollH=%d selected=%d hover=%d",
            tostring(label or "state"), width, height, #(list.items or {}),
            yScroll, scrollHeight, tonumber(list.selected) or -1,
            tonumber(list.mouseoverselected) or -1
        ))
    end
end

local function makeTileRows(results, maxColumns)
    local rows = {}
    maxColumns = maxColumns or 8

    -- Keep each row inside one tileset whenever possible. This mirrors the
    -- native picker, which draws a single texture sheet at a time, and avoids
    -- repeatedly switching between unrelated texture definition lists.
    local current = nil
    local currentTileset = nil

    for i = 1, #(results or {}) do
        local result = results[i]
        if result ~= nil then
            if current == nil or currentTileset ~= result.tileset or #current.tiles >= maxColumns then
                current = { tileset = result.tileset, tiles = {} }
                table.insert(rows, current)
                currentTileset = result.tileset
            end
            table.insert(current.tiles, result)
        end
    end

    return rows
end


local function trimTileLabel(text, font, maxWidth)
    text = tostring(text or "")
    if getTextManager():MeasureStringX(font, text) <= maxWidth then
        return text
    end
    local suffix = "..."
    for n = #text, 1, -1 do
        local candidate = string.sub(text, 1, n) .. suffix
        if getTextManager():MeasureStringX(font, candidate) <= maxWidth then
            return candidate
        end
    end
    return suffix
end

local function drawTileRow(list, y, item, alt)
    local row = item and item.item
    if row == nil then return y + (item.height or list.itemheight) end

    local rowHeight = item.height or list.itemheight
    local cardWidth = 142
    local cardHeight = rowHeight - 14
    local gap = 8
    local left = 8
    local top = y + 6
    local previewXPad = 6
    local previewYPad = 6
    local previewW = cardWidth - previewXPad * 2
    local previewH = cardHeight - 52

    -- Preserve the normal scrolling-list optimization: if this row is not
    -- visible, do no texture work at all.
    if (y + list:getYScroll() + rowHeight < 0) or (y + list:getYScroll() >= list.height) then
        return y + rowHeight
    end

    -- A small sheet hint makes this row behave like the native tiles picker.
    -- Only one hint is attempted per visible row, never during indexing.
    if row.tiles[1] ~= nil then
        pcall(function() getTexture(row.tiles[1].id) end)
    end

    for i = 1, #row.tiles do
        local result = row.tiles[i]
        local x = left + (i - 1) * (cardWidth + gap)
        if x + cardWidth > list.width - 4 then break end

        local hovered = list.mouseoverselected == item.index and list:isMouseOver()
        local selected = list.owner ~= nil and list.owner.selectedTileName == result.id

        -- Tile card background and the requested visible white outline.
        self = list
        self:drawRect(x, top, cardWidth, cardHeight, 0.22, 0.02, 0.02, 0.02)
        self:drawRectBorder(x, top, cardWidth, cardHeight, 0.95, 1, 1, 1)
        if hovered then
            self:drawRectBorder(x - 1, top - 1, cardWidth + 2, cardHeight + 2, 1.0, 1, 1, 1)
        end
        if selected then
            self:drawRectBorder(x + 2, top + 2, cardWidth - 4, cardHeight - 4, 1.0, 1, 1, 1)
        end

        local previewX = x + previewXPad
        local previewY = top + previewYPad
        self:drawRectBorder(previewX, previewY, previewW, previewH, 0.55, 1, 1, 1)

        local texture = resolveTileTexture(result.id)
        if texture ~= nil then
            self:drawTextureScaledAspect(texture, previewX + 2, previewY + 2, previewW - 4, previewH - 4, 1, 1, 1, 1)
        else
            self:drawTextCentre("NO PREVIEW", x + cardWidth / 2, previewY + previewH / 2 - 7, 1, 1, 1, 0.8, UIFont.Small)
        end

        local label = trimTileLabel(result.id, UIFont.Small, cardWidth - 10)
        self:drawTextCentre(label, x + cardWidth / 2, top + cardHeight - 35, 1, 1, 1, 0.95, UIFont.Small)
        local tilesetLabel = trimTileLabel(result.tileset, UIFont.Small, cardWidth - 10)
        self:drawTextCentre(tilesetLabel, x + cardWidth / 2, top + cardHeight - 19, 0.75, 0.75, 0.75, 0.85, UIFont.Small)

        local fav = BetterBrushPicker.isFavorite(result.id)
        self:drawTextCentre(fav and "★" or "☆", x + cardWidth - 14, top + 3, 1, 1, 1, 0.95, UIFont.Small)
    end

    diagnosticGridState(list, "drawRow")
    return y + rowHeight
end

local function tileRowClick(target, row)
    if target == nil or row == nil then return end
    local mx = target:getMouseX()
    local cardWidth = 142
    local gap = 8
    local left = 8
    local index = math.floor((mx - left) / (cardWidth + gap)) + 1

    if mx < left or index < 1 or index > #row.tiles then return end
    local cardX = left + (index - 1) * (cardWidth + gap)
    if mx > cardX + cardWidth then return end

    local result = row.tiles[index]
    if result == nil then return end

    if mx >= cardX + cardWidth - 34 then
        BetterBrushPicker.toggleFavorite(result.id)
        return
    end

    BetterBrushPicker.selectTile(result, target.character, target.owner)
    target:refreshRowsSelection()
end

local function buildTileRowList(list, results)
    list:clear()
    list.rows = makeTileRows(results, 8)
    for i = 1, #list.rows do
        list:addItem("", list.rows[i])
    end
    diagnosticGridState(list, "setResults")
end

local function install()
    if BetterBrushPicker.installed then return end
    if BrushToolChooseTileUI == nil or BrushToolTilePickerList == nil or ISBrushToolTileCursor == nil or ISScrollingListBox == nil then
        return false
    end

    BetterBrushPicker.installed = true
    BetterBrushPickerTileRowList = ISScrollingListBox:derive("BetterBrushPickerTileRowList")

    local ROW_HEIGHT = 166

    function BetterBrushPickerTileRowList:new(x, y, w, h, character, owner)
        local o = ISScrollingListBox.new(self, x, y, w, h)
        o.character = character
        o.owner = owner
        o.rows = {}
        o.itemheight = ROW_HEIGHT
        o:setFont(UIFont.Small, 0)
        o.itemheight = ROW_HEIGHT
        o.drawBorder = true
        o.backgroundColor = {r=0, g=0, b=0, a=0.35}
        o.onmousedown = tileRowClick
        o.target = o
        o.doDrawItem = drawTileRow
        o.itemheightoverride = {}
        return o
    end

    function BetterBrushPickerTileRowList:refreshRowsSelection()
        -- Nothing else is required. The selected tile is read directly from
        -- the owner during draw, and repaint is provided by the normal UI loop.
    end

    function BetterBrushPickerTileRowList:setResults(results)
        buildTileRowList(self, results or {})
        self:setYScroll(0)
        self.selected = (#self.items > 0) and 1 or -1
        self.mouseoverselected = -1
        diagnosticGridState(self, "results")
    end

    function BetterBrushPickerTileRowList:onMouseMove(dx, dy)
        ISScrollingListBox.onMouseMove(self, dx, dy)
    end

    function BetterBrushPickerTileRowList:onMouseMoveOutside(x, y)
        ISScrollingListBox.onMouseMoveOutside(self, x, y)
    end

    function BetterBrushPickerTileRowList:onMouseDown(x, y)
        ISScrollingListBox.onMouseDown(self, x, y)
    end

    function BetterBrushPickerTileRowList:onMouseWheel(del)
        local result = ISScrollingListBox.onMouseWheel(self, del)
        diagnosticGridState(self, "wheel")
        return result
    end

    -- Utility used by the row renderer. Kept local to this installation so
    -- unrelated UI code does not gain another global helper.
    function BetterBrushPickerTileRowList:prerender()
        ISScrollingListBox.prerender(self)
    end

    -- The vanilla UI uses a left tileset list. BetterBrushPicker replaces that
    -- list with a search-first gallery while retaining the same brush cursor.
    function BrushToolChooseTileUI.openPanel(x, y, playerObj)
        if y < 0 then y = 0 end
        if BrushToolChooseTileUI.instance == nil then
            local window = BrushToolChooseTileUI:new(x, y, 1220, 760, playerObj)
            window:initialise()
            window:addToUIManager()
            BrushToolChooseTileUI.instance = window
        end
    end

    function BrushToolChooseTileUI:createChildren()
        ISCollapsableWindow.createChildren(self)
        local th = self:titleBarHeight()
        local topY = th + 6

        self.searchEntryBox = ISTextEntryBox:new("", 8, topY, 420, 24)
        self.searchEntryBox.font = UIFont.Small
        self.searchEntryBox.onTextChange = BrushToolChooseTileUI.onTextChange
        self:addChild(self.searchEntryBox)

        local x = self.searchEntryBox:getRight() + 8
        for i = 1, #BetterBrushPicker.categories do
            local category = BetterBrushPicker.categories[i]
            local width = 70
            local button = ISButton:new(x, topY, width, 24, category, self, BrushToolChooseTileUI.onCategoryClick)
            button.internal = category
            button:initialise()
            button:instantiate()
            self:addChild(button)
            x = x + width + 3
        end

        local modeY = topY + 30
        self.viewModeButtons = {}
        local modeButtons = {
            { key = "All", title = "All Results", width = 100 },
            { key = "Favorites", title = "Favorites", width = 100 },
            { key = "Recent", title = "Recent", width = 100 },
        }
        local modeX = 8
        for i = 1, #modeButtons do
            local data = modeButtons[i]
            local button = ISButton:new(modeX, modeY, data.width, 24, data.title, self, BrushToolChooseTileUI.onViewModeClick)
            button.internal = data.key
            button:initialise()
            button:instantiate()
            self:addChild(button)
            self.viewModeButtons[data.key] = button
            modeX = modeX + data.width + 4
        end

        local contentTop = modeY + 30
        local bottomHeight = 46
        local tilesWidth = self.width - 16
        local tilesHeight = self.height - contentTop - bottomHeight

        self.tilesList = BetterBrushPickerTileRowList:new(8, contentTop, tilesWidth, tilesHeight, self.character, self)
        self.tilesList.anchorRight = true
        self.tilesList.anchorBottom = true
        self.tilesList:initialise()
        self.tilesList:instantiate()
        self.tilesList:addScrollBars()
        self:addChild(self.tilesList)

        self.selectedTileName = "No tile selected"
        self.selectedResult = nil

        loadUserState()
        BetterBrushPicker.startIndexBuild()
        self:refreshResults()
    end

    function BrushToolChooseTileUI:onTextChange()
        if BrushToolChooseTileUI.instance ~= nil then
            BrushToolChooseTileUI.instance.selectedResult = nil
            BrushToolChooseTileUI.instance:refreshResults()
        end
    end

    function BrushToolChooseTileUI:onCategoryClick(button)
        BetterBrushPicker.activeCategory = button.internal or "All"
        self.selectedResult = nil
        self:refreshResults()
    end

    function BrushToolChooseTileUI:onViewModeClick(button)
        BetterBrushPicker.viewMode = button.internal or "All"
        self.selectedResult = nil
        self:refreshResults()
    end

    function BrushToolChooseTileUI:refreshResults()
        if self.tilesList == nil then return end

        if not BetterBrushPicker.indexReady then
            self.tilesList:setResults({})
            self.selectedTileName = BetterBrushPicker.indexBuilding and "Indexing tiles..." or "Preparing index..."
            return
        end

        local searchText = self.searchEntryBox:getInternalText()
        BetterBrushPicker.lastSearch = searchText
        local category = BetterBrushPicker.activeCategory
        local results = BetterBrushPicker.buildSearchResults(searchText, category, BetterBrushPicker.viewMode)

        self.currentResults = results
        self.tilesList:setResults(results)

        if #results == 0 then
            self.selectedTileName = "No matching tiles"
        elseif self.selectedResult == nil then
            self.selectedTileName = "Results: " .. tostring(#results) .. " (click a tile)"
        end
    end

    function BrushToolChooseTileUI:render()
        ISCollapsableWindow.render(self)
        local footerY = self.height - 34
        self:drawText(
            "Selected: " .. tostring(self.selectedTileName or "None"),
            10, footerY, 1, 1, 1, 0.95, UIFont.Small
        )

        local state = BetterBrushPicker.indexState
        local progress = ""
        if BetterBrushPicker.indexReady and state ~= nil then
            progress = string.format("Indexed %d tiles", state.added)
        elseif BetterBrushPicker.indexBuilding and state ~= nil then
            progress = string.format("Indexing tiles: %d found / %d actual IDs processed", state.added, state.checked)
        else
            progress = "Starting tile index..."
        end
        self:drawTextRight(progress, self.width - 10, footerY, 1, 1, 1, 0.8, UIFont.Small)
    end

    function BrushToolChooseTileUI:close()
        BrushToolChooseTileUI.instance = nil
        self:setVisible(false)
        self:removeFromUIManager()
    end

    function BrushToolChooseTileUI:new(x, y, width, height, character)
        local o = ISCollapsableWindow.new(self, x, y, width, height)
        o:setResizable(true)
        o.title = "Better Brush Picker — Individual Tiles"
        o.character = character
        return o
    end

    local VERSION = "0.5.0"
    log("Installed v" .. VERSION .. " successfully.")
    log("Version marker: BetterBrushPicker source v" .. VERSION)
    log("UI architecture: native ISScrollingListBox tile rows (8 tiles per row).")
    return true
end

local function tick()
    if not BetterBrushPicker.installed then
        install()
    end
    if BetterBrushPicker.installed then
        BetterBrushPicker.tickIndexBuild()
    end
end

local function onGameBoot()
    install()
    Events.OnTick.Add(tick)
end

Events.OnGameBoot.Add(onGameBoot)
