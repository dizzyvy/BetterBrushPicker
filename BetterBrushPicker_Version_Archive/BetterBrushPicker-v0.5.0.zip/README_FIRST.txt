BETTER BRUSH PICKER v0.5.0

1. Remove older BetterBrushPicker folders before installing this build.
2. Copy the `42` and `common` folders into the PZ mods location so the mod folder contains `42/mod.info` and the `42/media/lua/client/BetterBrushPicker/BetterBrushPicker.lua`.
3. On startup the console should say:
   [BetterBrushPicker] Installed v0.5.0 successfully.
   [BetterBrushPicker] UI architecture: native ISScrollingListBox tile rows (8 tiles per row).
4. Open the vanilla Brush Tool and use the Better Brush Picker gallery.

This build intentionally does not bulk-load all 61,740 textures. Textures are resolved lazily only for visible gallery rows.
