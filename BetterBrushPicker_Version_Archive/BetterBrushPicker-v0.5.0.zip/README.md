# Better Brush Picker

Project Zomboid Build 42 mod by Dizzy.

## Current version

**v0.5.0**

## What it does

Better Brush Picker replaces the vanilla Brush Tool tile-selection window with a searchable visual browser of individual brush-compatible tiles. Actual placement continues to use the vanilla `ISBrushToolTileCursor`.

### Current features

- Individual-tile visual results
- Search by tile ID, tileset, category, and semantic aliases
- Category filters
- Direct Build 42 tile enumeration with `IsoWorld:getAllTilesName()` and `IsoWorld:getAllTiles(filename)`
- Persistent per-tileset cache
- Incremental indexing in small bursts
- No full-index/global sort during scan completion
- Centralized guarded tile validation and selection
- Spaced tile cards with bounded previews and aligned mouse hitboxes
- Hover outline showing the active tile card

### v0.5.0 tile visibility
v0.5.0 adds bright white outlines around each tile card and its preview area. The preview outline remains visible even when a thumbnail is missing or still resolving, making the individual tile items easier to distinguish. It also adds an explicit startup version marker to the console.

### v0.4.4 texture loading
v0.4.4 incrementally warms the texture pages for all discovered tilesets using the same `getTexture(<tileset>_0)` lookup pattern used by the vanilla Brush Tool. This keeps texture work out of a single frame and allows the custom grid to resolve thumbnails for later tilesets.

### v0.3.3 UI fixes

The v0.3.3 release fixes the visual grid layout without changing the working indexing/cache system from v0.2.9 or the reliability changes from v0.3.0.

## Installation

For the installed mod, keep the `BetterBrushPicker/42/` structure intact and place the mod in your Project Zomboid mods directory. Do not put the ZIP itself in the mods directory.

## Development

Historical experimental builds are preserved separately in the repository archive. Old releases should be treated as immutable snapshots; new fixes get new version numbers.

## Author

**Dizzy**

Steam: https://steamcommunity.com/id/illMindOfDizzy/


## v0.5.0 rebuild

The visual gallery was rebuilt around Project Zomboid's native `ISScrollingListBox`. Results are grouped into compact rows of up to eight tiles. The custom stencil/grid implementation from v0.3-v0.4 was removed. Thumbnail lookup uses the same `getTexture(tileId)` path as the vanilla tile picker and only performs the sprite-loading fallback for tiles that are actually visible. The persistent direct tile index and cache format remain compatible with the existing BBP_CACHE_7 files.
