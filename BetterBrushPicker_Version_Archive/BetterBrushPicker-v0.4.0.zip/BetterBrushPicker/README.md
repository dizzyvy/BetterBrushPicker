# Better Brush Picker

Project Zomboid Build 42 mod by Dizzy.

## Current version

**v0.3.3**

## What it does

Better Brush Picker replaces the vanilla Brush Tool tile-selection window with a searchable visual browser of individual brush-compatible tiles. Actual placement continues to use the vanilla `ISBrushToolTileCursor`.

### Current features

- Individual-tile visual results
- Search by tile ID, tileset, category, and semantic aliases
- Category filters
- Direct Build 42 tile enumeration with `IsoWorld:getAllTilesName()` and `IsoWorld:getAllTiles(filename)`
- Persistent per-tileset cache
- Incremental indexing in small bursts
- No full-index/global sort during scan completion
- Centralized guarded tile validation and selection
- Spaced tile cards with bounded previews and aligned mouse hitboxes
- Hover outline showing the active tile card

### v0.3.3 UI fixes

The v0.3.3 release fixes the visual grid layout without changing the working indexing/cache system from v0.2.9 or the reliability changes from v0.3.0.

## Installation

For the installed mod, keep the `BetterBrushPicker/42/` structure intact and place the mod in your Project Zomboid mods directory. Do not put the ZIP itself in the mods directory.

## Development

Historical experimental builds are preserved separately in the repository archive. Old releases should be treated as immutable snapshots; new fixes get new version numbers.

## Author

**Dizzy**

Steam: https://steamcommunity.com/id/illMindOfDizzy/
