-- Better Brush Picker
-- Build 42
-- Version 0.4.6
-- Author: Dizzy
--
-- v0.2.8 replaces the old fixed-slot probing scan with direct enumeration of the tiles exposed by IsoWorld:getAllTiles. Persistent per-definition-list caching is kept.
-- v0.2.9 avoids full-index and full-result sorting so completion does not block the game thread on ~61k entries.
-- v0.3.0 keeps that indexing path intact and makes tile filtering/selection use centralized, guarded functions.
-- v0.3.1 fixes tile-grid scrolling/hitbox alignment and gives each tile card
-- dedicated spacing and bounded text so labels and clickable areas do not overlap.
-- v0.3.2 clamps custom scrolling to the real content bounds and derives visible
-- rows from the viewport so scrolling cannot move into an empty/black region.
-- v0.3.3 overrides the inherited Brush Tool list stencil so the custom grid
-- uses its full live viewport instead of the vanilla list clip region.
-- v0.4.0 adds persistent Favorites and Recent tile lists without changing the
-- underlying index/cache format or vanilla brush-cursor selection path.
-- v0.4.1 is a diagnostic build that logs the tile-grid viewport, scroll metrics,
-- parent geometry, scrollbar geometry, and calculated visible rows so the remaining
-- rendering/clipping problem can be isolated without changing the index itself.
-- v0.4.2 stops deriving the custom grid from BrushToolTilePickerList. The custom
-- grid now derives directly from ISPanel so the vanilla picker cannot impose hidden
-- list rendering/scroll state on the custom grid.
-- v0.4.3 incrementally warms tilesets, but sheet_0 is not guaranteed to be a
-- valid representative sprite for every definition list.
-- v0.4.4 resolves thumbnails through both direct texture lookup and the loaded
-- IsoSprite animation frame, and warms each definition using its actual first
-- brush-compatible tile ID instead of assuming an _0 entry exists.
-- v0.4.5 improves tile-card visibility with white card/preview outlines and
-- uses one explicit version marker for startup logging.
-- v0.4.6 uses IsoSprite texture-frame methods and can explicitly reload a
-- sprite frame when direct texture lookup has not materialized the tile.
-- The picker no longer requires the
-- user to choose a tilesheet before browsing results. Search results are
-- individual sprite/tile IDs and selection still uses the vanilla
-- ISBrushToolTileCursor.

local BetterBrushPicker = {}
BetterBrushPicker.DEBUG = false
BetterBrushPicker.DIAGNOSTIC = false
BetterBrushPicker.textureWarmup = { queue = {}, index = 1, attempted = 0, loaded = 0, ready = false }
BetterBrushPicker.thumbnailTextureCache = {}
BetterBrushPicker.thumbnailStats = { direct = 0, spriteFrame = 0, reloaded = 0, missing = 0, logged = 0 }
BetterBrushPicker.thumbnailLoggedIds = {}
BetterBrushPicker.installed = false
BetterBrushPicker.indexReady = false
BetterBrushPicker.indexBuilding = false
BetterBrushPicker.index = {}
BetterBrushPicker.indexById = {}
BetterBrushPicker.tilesets = {}
BetterBrushPicker.activeCategory = "All"
BetterBrushPicker.viewMode = "All"
BetterBrushPicker.lastSearch = ""
BetterBrushPicker.indexState = nil
BetterBrushPicker.favorites = {}
BetterBrushPicker.favoriteOrder = {}
BetterBrushPicker.recentOrder = {}
BetterBrushPicker.userStateLoaded = false

-- Persistent cache and incremental work settings.
local CACHE_PREFIX = "BetterBrushPicker_tileset_"
local USER_STATE_FILE = "BetterBrushPicker_user_state.txt"
local MAX_RECENT = 50
local TILES_PER_BURST = 128
local TEXTURES_PER_WARMUP_TICK = 4

BetterBrushPicker.categories = {
    "All", "Furniture", "Walls", "Floors", "Decor", "Doors", "Windows", "Plants", "Roofs", "Other"
}

-- These aliases are deliberately broad. They supplement the actual sprite
-- and tileset names and will be refined in later versions with more exact
-- per-sprite semantic tagging.
BetterBrushPicker.aliases = {
    chair = "chair chairs seat seating stool bench furniture",
    couch = "couch sofa sofas loveseat seating furniture",
    sofa = "sofa sofas couch couches loveseat seating furniture",
    table = "table tables desk furniture",
    desk = "desk desks table furniture office",
    bed = "bed beds bedding furniture",
    dresser = "dresser dressers storage furniture",
    shelf = "shelf shelves shelving storage furniture",
    cabinet = "cabinet cabinets cupboard storage furniture",
    locker = "locker lockers storage",
    fridge = "fridge refrigerator refrigeration freezer appliance appliances",
    refrigerator = "fridge refrigerator refrigeration freezer appliance appliances",
    freezer = "fridge refrigerator refrigeration freezer appliance appliances",
    stove = "stove cooker oven cooking appliance appliances",
    oven = "oven stove cooker cooking appliance appliances",
    microwave = "microwave appliance appliances cooking",
    sink = "sink sinks bathroom plumbing fixture fixtures counter",
    toilet = "toilet toilets bathroom plumbing fixture fixtures",
    bathtub = "bathtub tub bathroom plumbing fixture fixtures",
    shower = "shower bathroom plumbing fixture fixtures",
    window = "window windows curtain curtains fixture fixtures",
    door = "door doors doorway frame gate fixture fixtures",
    wall = "wall walls brick wood stone clapboard fence fencing railing",
    floor = "floor floors ground street road sidewalk curb carpet wood tile stone gravel dirt grass",
    plant = "plant plants tree trees bush bushes flower flowers vine vines vegetation foliage",
    tree = "tree trees vegetation foliage",
    grass = "grass vegetation foliage floor",
    roof = "roof roofs snow roofcap",
    lamp = "lamp lighting light lights fixture fixtures",
    light = "lamp lighting light lights fixture fixtures",
    rug = "rug rugs carpet carpets floor",
    sign = "sign signs signage notice notices poster advertising",
}

local function log(message)
    print("[BetterBrushPicker] " .. tostring(message))
end

local function debugLog(message)
    if BetterBrushPicker.DEBUG then
        print("[BetterBrushPicker][DEBUG] " .. tostring(message))
    end
end

local function diagnosticLog(message)
    if BetterBrushPicker.DIAGNOSTIC then
        print("[BetterBrushPicker][DIAG] " .. tostring(message))
    end
end

local function lower(value)
    return string.lower(tostring(value or ""))
end

local function contains(text, needle)
    return string.find(lower(text), lower(needle), 1, true) ~= nil
end

local function categoryFor(name)
    local n = lower(name)
    if contains(n, "door") or contains(n, "gate") then return "Doors" end
    if contains(n, "window") then return "Windows" end
    if contains(n, "roof") then return "Roofs" end
    if contains(n, "floor") or contains(n, "street") or contains(n, "curb") or contains(n, "blend") then return "Floors" end
    if contains(n, "wall") or contains(n, "fenc") or contains(n, "rail") then return "Walls" end
    if contains(n, "furniture") or contains(n, "appliance") or contains(n, "seating") or contains(n, "shelving")
        or contains(n, "storage") or contains(n, "counter") or contains(n, "sink") or contains(n, "bathroom")
        or contains(n, "bedding") or contains(n, "table") or contains(n, "desks") then return "Furniture" end
    if contains(n, "tree") or contains(n, "bush") or contains(n, "flower") or contains(n, "plant")
        or contains(n, "vegetation") or contains(n, "foliage") then return "Plants" end
    if contains(n, "sign") or contains(n, "notice") or contains(n, "overlay") or contains(n, "graffiti")
        or contains(n, "grime") or contains(n, "trash") or contains(n, "junk") or contains(n, "lighting")
        or contains(n, "light") or contains(n, "curtain") or contains(n, "rug") then return "Decor" end
    return "Other"
end

local function tileBaseName(fullName)
    local s = tostring(fullName or "")
    local base = s:match("^([^%.]+)")
    return base or s
end

local function isBrushTileId(tileName)
    local s = tostring(tileName or "")
    if s == "" then return false end
    local numericIndex = tonumber(s:match("_(%d+)$"))
    if numericIndex == nil then return false end
    return numericIndex >= 0 and numericIndex <= 2047
end

local function splitSearch(text)
    local tokens = {}
    for token in lower(text):gmatch("%S+") do
        table.insert(tokens, token)
    end
    return tokens
end

local function matchesTokens(searchText, tokens)
    if #tokens == 0 then return true end

    local text = lower(searchText)
    for i = 1, #tokens do
        local token = lower(tokens[i])
        local matched = string.find(text, token, 1, true) ~= nil

        if not matched then
            local aliasText = BetterBrushPicker.aliases[token]
            if aliasText ~= nil then
                for aliasToken in lower(aliasText):gmatch("%S+") do
                    if string.find(text, aliasToken, 1, true) ~= nil then
                        matched = true
                        break
                    end
                end
            end
        end

        if not matched then return false end
    end

    return true
end

local function buildSearchText(tileName, tilesetName, category, parent, spriteType)
    local text = lower(tostring(tileName or "") .. " " .. tostring(tilesetName or "") .. " " .. tostring(category or "") .. " " .. tostring(parent or "") .. " " .. tostring(spriteType or ""))

    -- Add semantic aliases based on the actual tileset name. These aliases
    -- improve searches such as "chair", "fridge", and "window" while each
    -- result remains the individual tile ID.
    local n = lower(tilesetName)
    if contains(n, "seating") then text = text .. " chair chairs seat seating stool bench couch sofa loveseat " end
    if contains(n, "bedding") then text = text .. " bed beds mattress bedding " end
    if contains(n, "refriger") then text = text .. " fridge refrigerator freezer appliance " end
    if contains(n, "cooking") then text = text .. " stove oven cooker microwave cooking appliance " end
    if contains(n, "bathroom") then text = text .. " toilet sink bathtub tub shower bathroom plumbing fixture " end
    if contains(n, "windows") then text = text .. " window windows curtain curtains " end
    if contains(n, "doors") then text = text .. " door doors doorway frame gate " end
    if contains(n, "tables") then text = text .. " table tables desk " end
    if contains(n, "shelving") then text = text .. " shelf shelves shelving storage " end
    if contains(n, "storage") then text = text .. " cabinet cupboard locker storage " end
    if contains(n, "lighting") then text = text .. " lamp light lighting fixture " end
    if contains(n, "plants") or contains(n, "vegetation") then text = text .. " plant tree bush flower vine vegetation foliage " end

    return text
end

local function uniqueTilesets()
    local result = {}
    local seen = {}
    local world = getWorld()

    -- Prefer the same definition-name list used by B42's direct tile API.
    local namesOk, names = pcall(function() return world:getAllTilesName() end)
    if namesOk and names ~= nil then
        for i = 0, names:size() - 1 do
            local imageName = tostring(names:get(i))
            local base = imageName:match("^([^%.]+)") or imageName
            if base ~= "" and not seen[base] then
                seen[base] = true
                table.insert(result, base)
            end
        end
    end

    -- Fallback only if the direct definition-name API returns nothing.
    if #result == 0 then
        local images = world:getTileImageNames()
        if images == nil then return result end
        for i = 0, images:size() - 1 do
            local imageName = tostring(images:get(i))
            local base = imageName:match("^([^%.]+)") or imageName
            if base ~= "" and not seen[base] then
                seen[base] = true
                table.insert(result, base)
            end
        end
    end

    table.sort(result)
    return result
end

-- Build a direct queue from B42's actual tile-definition lists.
-- IMPORTANT: getAllTiles() returns a Java HashMap, but its keySet()/iterator()
-- methods are not exposed to Kahlua reliably in the target B42 build. The
-- public getAllTilesName() + getAllTiles(filename) route is safer here.
local function getTileDefinitionNames(world)
    local ok, names = pcall(function() return world:getAllTilesName() end)
    if not ok or names == nil then
        return nil, "IsoWorld:getAllTilesName() failed"
    end
    local sizeOk, size = pcall(function() return names:size() end)
    if not sizeOk or size == nil then
        return nil, "IsoWorld:getAllTilesName() returned an unusable list"
    end
    return names, nil
end

local function buildDirectTileLookup()
    local world = getWorld()
    local names, namesError = getTileDefinitionNames(world)
    if names == nil then
        log("ERROR: " .. tostring(namesError))
        return nil, 0, 0
    end

    local queue = {}
    local seen = {}
    local totalDirectIds = 0
    local failedSets = 0
    local definitionCount = names:size()

    for i = 0, definitionCount - 1 do
        local nameOk, filename = pcall(function() return tostring(names:get(i)) end)
        if nameOk and filename ~= nil and filename ~= "" and filename ~= "nil" then
            -- Keep the exact filename returned by B42. Do not strip its
            -- extension before calling getAllTiles(filename).
            local tileset = tileBaseName(filename)
            if tileset ~= "" and not seen[tileset] then
                local listOk, tileList = pcall(function()
                    return world:getAllTiles(filename)
                end)

                -- Defensive fallback for builds where the list is keyed by
                -- the base name rather than the definition filename.
                if (not listOk or tileList == nil) and tileset ~= filename then
                    listOk, tileList = pcall(function()
                        return world:getAllTiles(tileset)
                    end)
                end

                local count = 0
                if listOk and tileList ~= nil then
                    local sizeOk, size = pcall(function() return tileList:size() end)
                    if sizeOk and size ~= nil then
                        count = size
                    else
                        listOk = false
                    end
                end

                seen[tileset] = true
                if listOk and tileList ~= nil then
                    table.insert(queue, {
                        tileset = tileset,
                        filename = filename,
                        tiles = tileList,
                        count = count,
                    })
                    totalDirectIds = totalDirectIds + count
                else
                    failedSets = failedSets + 1
                    print(string.format("[BetterBrushPicker] WARNING: could not enumerate tile IDs for %s", filename))
                end
            end
        end
    end

    log(string.format(
        "Direct tile enumeration found %d actual tile IDs across %d tilesets (%d definition lists failed).",
        totalDirectIds, #queue, failedSets
    ))
    return queue, totalDirectIds, failedSets
end

local function sanitizeFilePart(value)
    local s = tostring(value or "")
    s = s:gsub("[^%w%._%-]", "_")
    if s == "" then s = "unknown" end
    return s
end

local function cacheFileFor(definitionFilename)
    return CACHE_PREFIX .. sanitizeFilePart(definitionFilename) .. ".txt"
end

local function writeLine(writer, value)
    writer:write(tostring(value or "") .. "\n")
end

local function arrayContains(array, value)
    for i = 1, #array do
        if array[i] == value then return true end
    end
    return false
end

local function removeFromArray(array, value)
    for i = #array, 1, -1 do
        if array[i] == value then
            table.remove(array, i)
        end
    end
end

local function loadUserState()
    if BetterBrushPicker.userStateLoaded then return end
    BetterBrushPicker.userStateLoaded = true

    local reader = getFileReader(USER_STATE_FILE, false)
    if not reader then return end

    local line = reader:readLine()
    if line ~= "BBP_USER_STATE_1" then
        reader:close()
        return
    end

    while true do
        line = reader:readLine()
        if line == nil or line == "END" then break end

        local kind, id = line:match("^([^|]+)|(.+)$")
        if kind == "FAV" and id ~= nil and isBrushTileId(id) then
            if not BetterBrushPicker.favorites[id] then
                BetterBrushPicker.favorites[id] = true
                table.insert(BetterBrushPicker.favoriteOrder, id)
            end
        elseif kind == "REC" and id ~= nil and isBrushTileId(id) then
            if not arrayContains(BetterBrushPicker.recentOrder, id) then
                table.insert(BetterBrushPicker.recentOrder, id)
            end
        end
    end

    reader:close()

    while #BetterBrushPicker.recentOrder > MAX_RECENT do
        table.remove(BetterBrushPicker.recentOrder)
    end

    debugLog(string.format("Loaded user state: %d favorites, %d recent tiles.",
        #BetterBrushPicker.favoriteOrder, #BetterBrushPicker.recentOrder))
end

local function saveUserState()
    local writer = getFileWriter(USER_STATE_FILE, true, false)
    if not writer then
        log("WARNING: could not save favorites/recent tile state.")
        return false
    end

    writeLine(writer, "BBP_USER_STATE_1")

    for i = 1, #BetterBrushPicker.favoriteOrder do
        local id = BetterBrushPicker.favoriteOrder[i]
        if BetterBrushPicker.favorites[id] then
            writeLine(writer, "FAV|" .. id)
        end
    end

    for i = 1, #BetterBrushPicker.recentOrder do
        writeLine(writer, "REC|" .. BetterBrushPicker.recentOrder[i])
    end

    writeLine(writer, "END")
    writer:close()
    return true
end

function BetterBrushPicker.isFavorite(tileName)
    loadUserState()
    return BetterBrushPicker.favorites[tostring(tileName or "")] == true
end

function BetterBrushPicker.toggleFavorite(tileName)
    local id = tostring(tileName or "")
    if id == "" or not isBrushTileId(id) then return false end
    loadUserState()

    if BetterBrushPicker.favorites[id] then
        BetterBrushPicker.favorites[id] = nil
        removeFromArray(BetterBrushPicker.favoriteOrder, id)
    else
        BetterBrushPicker.favorites[id] = true
        table.insert(BetterBrushPicker.favoriteOrder, id)
    end

    saveUserState()
    if BrushToolChooseTileUI ~= nil and BrushToolChooseTileUI.instance ~= nil then
        BrushToolChooseTileUI.instance:refreshResults()
    end
    return true
end

function BetterBrushPicker.addRecent(tileName)
    local id = tostring(tileName or "")
    if id == "" or not isBrushTileId(id) then return end
    loadUserState()

    local wasFirst = BetterBrushPicker.recentOrder[1] == id
    removeFromArray(BetterBrushPicker.recentOrder, id)
    table.insert(BetterBrushPicker.recentOrder, 1, id)
    while #BetterBrushPicker.recentOrder > MAX_RECENT do
        table.remove(BetterBrushPicker.recentOrder)
    end

    if not wasFirst then
        saveUserState()
    end
end

local function trySpriteTextureMethods(sprite, spriteName)
    if sprite == nil then return nil, "no-sprite" end
    if IsoDirections == nil then return nil, "no-directions" end

    local directions = {
        IsoDirections.N, IsoDirections.NE, IsoDirections.E, IsoDirections.SE,
        IsoDirections.S, IsoDirections.SW, IsoDirections.W, IsoDirections.NW
    }

    -- Build 42 exposes direct IsoSprite methods for frame texture access. These
    -- are preferable to poking at the Java field name because the field is
    -- lower-case in the current API.
    for i = 1, #directions do
        local direction = directions[i]
        if direction ~= nil then
            local ok, texture = pcall(function()
                return sprite:getTextureForCurrentFrame(direction)
            end)
            if ok and texture ~= nil then
                return texture, "spriteCurrent"
            end

            ok, texture = pcall(function()
                return sprite:getTextureForFrame(0, direction)
            end)
            if ok and texture ~= nil then
                return texture, "spriteFrame"
            end
        end
    end

    -- Fallback through the documented animation-frame accessor. This avoids
    -- depending on a particular capitalization of the Java field.
    local okFrame, frame = pcall(function()
        return sprite:getAnimFrame(0)
    end)
    if okFrame and frame ~= nil then
        for i = 1, #directions do
            local direction = directions[i]
            if direction ~= nil then
                local ok, texture = pcall(function()
                    return frame:getTexture(direction)
                end)
                if ok and texture ~= nil then
                    return texture, "frameAccessor"
                end
            end
        end
    end

    return nil, "no-frame-texture"
end

local function resolveSpriteFrameTexture(spriteName)
    local ok, sprite = pcall(function() return getSprite(spriteName) end)
    if not ok or sprite == nil then
        return nil, "no-sprite"
    end

    local texture, source = trySpriteTextureMethods(sprite, spriteName)
    if texture ~= nil then
        return texture, source
    end

    -- IsoSprite exposes the same loader used when tile-definition sprites are
    -- materialized. Re-run it once for an on-screen tile that still has no
    -- usable frame texture, then try the frame accessors again.
    local reloadOk = pcall(function()
        sprite:LoadFramesNoDirPageSimple(spriteName)
    end)
    if reloadOk then
        texture, source = trySpriteTextureMethods(sprite, spriteName)
        if texture ~= nil then
            return texture, "reloaded-" .. tostring(source)
        end
    end

    -- Last documented sprite-side texture loader fallback.
    local loadOk, texture = pcall(function()
        return sprite:LoadSingleTexture(spriteName)
    end)
    if loadOk and texture ~= nil then
        return texture, "singleTexture"
    end

    return nil, "missing"
end

local function resolveTileTexture(tileName)
    local id = tostring(tileName or "")
    if id == "" then return nil end

    local cached = BetterBrushPicker.thumbnailTextureCache[id]
    if cached ~= nil then
        return cached
    end

    local ok, texture = pcall(function()
        return getTexture(id)
    end)
    if ok and texture ~= nil then
        BetterBrushPicker.thumbnailTextureCache[id] = texture
        BetterBrushPicker.thumbnailStats.direct = BetterBrushPicker.thumbnailStats.direct + 1
        return texture
    end

    texture, source = resolveSpriteFrameTexture(id)
    if texture ~= nil then
        BetterBrushPicker.thumbnailTextureCache[id] = texture
        if string.sub(tostring(source), 1, 8) == "reloaded" then
            BetterBrushPicker.thumbnailStats.reloaded = BetterBrushPicker.thumbnailStats.reloaded + 1
        else
            BetterBrushPicker.thumbnailStats.spriteFrame = BetterBrushPicker.thumbnailStats.spriteFrame + 1
        end
        if BetterBrushPicker.thumbnailStats.logged < 12 then
            BetterBrushPicker.thumbnailStats.logged = BetterBrushPicker.thumbnailStats.logged + 1
            log(string.format("Thumbnail resolved via %s: %s", tostring(source), id))
        end
        return texture
    end

    BetterBrushPicker.thumbnailStats.missing = BetterBrushPicker.thumbnailStats.missing + 1
    if BetterBrushPicker.thumbnailStats.logged < 24 and not BetterBrushPicker.thumbnailLoggedIds[id] then
        BetterBrushPicker.thumbnailLoggedIds[id] = true
        BetterBrushPicker.thumbnailStats.logged = BetterBrushPicker.thumbnailStats.logged + 1
        log(string.format("Thumbnail unresolved after all lookup paths: %s", id))
    end
    return nil
end

local function startTextureWarmup(tileQueue)
    local queue = {}

    if tileQueue ~= nil and #tileQueue > 0 then
        for i = 1, #tileQueue do
            local entry = tileQueue[i]
            local firstId = nil
            local list = entry.tiles
            if list ~= nil then
                for j = 0, (entry.count or 0) - 1 do
                    local ok, value = pcall(function() return tostring(list:get(j)) end)
                    if ok and value ~= "nil" and isBrushTileId(value) then
                        firstId = value
                        break
                    end
                end
            end
            if firstId ~= nil then
                table.insert(queue, { tileset = entry.tileset, tileId = firstId })
            end
        end
    end

    if #queue == 0 then
        local fallback = uniqueTilesets()
        for i = 1, #fallback do
            table.insert(queue, { tileset = fallback[i], tileId = fallback[i] .. "_0" })
        end
    end

    BetterBrushPicker.textureWarmup = {
        queue = queue,
        index = 1,
        attempted = 0,
        loaded = 0,
        ready = (#queue == 0),
    }

    if #queue > 0 then
        log(string.format("Texture warmup started: %d tilesets, %d actual-tile lookups per tick.", #queue, TEXTURES_PER_WARMUP_TICK))
    else
        log("Texture warmup skipped: no tilesets found.")
    end
end

function BetterBrushPicker.tickTextureWarmup()
    local warmup = BetterBrushPicker.textureWarmup
    if warmup == nil or warmup.ready then return end

    local budget = TEXTURES_PER_WARMUP_TICK
    while budget > 0 and warmup.index <= #warmup.queue do
        local entry = warmup.queue[warmup.index]
        warmup.index = warmup.index + 1
        warmup.attempted = warmup.attempted + 1
        budget = budget - 1

        local texture = resolveTileTexture(entry.tileId)
        if texture ~= nil then
            warmup.loaded = warmup.loaded + 1
        end
    end

    if warmup.index > #warmup.queue then
        warmup.ready = true
        log(string.format("Texture warmup complete: %d/%d tilesets resolved through actual tile IDs.", warmup.loaded, warmup.attempted))
    end
end

local function readCacheFile(fileName)
    local reader = getFileReader(fileName, false)
    if not reader then return nil end

    local rows = {}
    local line = reader:readLine()
    if line ~= "BBP_CACHE_7" then
        reader:close()
        return nil
    end

    line = reader:readLine()
    while line ~= nil do
        if line == "END" then
            reader:close()
            return rows
        end
        local id, tileset, category = line:match("^([^|]*)|([^|]*)|([^|]*)$")
        if id and tileset and category and isBrushTileId(id) then
            table.insert(rows, {
                id = id,
                name = id,
                tileset = tileset,
                category = category,
                parent = "",
                spriteType = "",
                searchText = buildSearchText(id, tileset, category, "", ""),
            })
        else
            reader:close()
            return nil
        end
        line = reader:readLine()
    end

    reader:close()
    return nil
end

local function writeCacheFile(tileset, definitionFilename, rows)
    local fileName = cacheFileFor(definitionFilename or tileset)
    local writer = getFileWriter(fileName, true, false)
    if not writer then return false end

    writeLine(writer, "BBP_CACHE_7")
    for i = 1, #rows do
        local result = rows[i]
        writeLine(writer, result.id .. "|" .. result.tileset .. "|" .. result.category)
    end
    writeLine(writer, "END")
    writer:close()
    return true
end


local function loadExistingCacheSets(tilesetQueue, failedDefinitions)
    local loaded = {}
    local missing = {}
    local cachedSets = 0

    for i = 1, #tilesetQueue do
        local entry = tilesetQueue[i]
        local tileset = entry.tileset
        local rows = readCacheFile(cacheFileFor(entry.filename or tileset))
        if rows then
            for j = 1, #rows do
                table.insert(loaded, rows[j])
                BetterBrushPicker.indexById[rows[j].id] = rows[j]
            end
            cachedSets = cachedSets + 1
        else
            table.insert(missing, entry)
        end
    end

    BetterBrushPicker.index = loaded
    BetterBrushPicker.tilesets = missing
    BetterBrushPicker.indexState = {
        tilesetIndex = 1,
        tileIndex = 0,
        added = #loaded,
        checked = 0,
        cached = cachedSets,
        totalTilesets = #tilesetQueue,
        totalActualTiles = 0,
        missingTilesets = 0,
        failedDefinitions = failedDefinitions or 0,
    }

    for i = 1, #missing do
        local count = missing[i].count or 0
        BetterBrushPicker.indexState.totalActualTiles = BetterBrushPicker.indexState.totalActualTiles + count
        if count == 0 then BetterBrushPicker.indexState.missingTilesets = BetterBrushPicker.indexState.missingTilesets + 1 end
    end

    if cachedSets > 0 then
        log(string.format("Loaded %d cached tilesets (%d tiles); %d tilesets remain for direct enumeration.", cachedSets, #loaded, #missing))
    end

    return cachedSets > 0 or #missing == 0
end

local function finishIndex()
    local state = BetterBrushPicker.indexState
    BetterBrushPicker.indexBuilding = false
    BetterBrushPicker.indexReady = true
    log(string.format("Full index ready: %d individual tiles checked=%d; cached sets=%d (no final global sort).",
        state and state.added or #BetterBrushPicker.index,
        state and state.checked or 0,
        state and state.cached or 0))

    if BrushToolChooseTileUI ~= nil and BrushToolChooseTileUI.instance ~= nil then
        BrushToolChooseTileUI.instance:refreshResults()
    end
end

function BetterBrushPicker.startIndexBuild()
    if BetterBrushPicker.indexBuilding or BetterBrushPicker.indexReady then return end

    local allTilesets = uniqueTilesets()
    local tileQueue, directTotal, failedSets = buildDirectTileLookup()
    startTextureWarmup(tileQueue)
    BetterBrushPicker.index = {}
    BetterBrushPicker.indexById = {}
    BetterBrushPicker.tilesets = {}

    if tileQueue == nil then
        tileQueue = {}
    end

    loadExistingCacheSets(tileQueue, failedSets)

    if (#tileQueue == 0 or directTotal == 0) and #allTilesets > 0 then
        BetterBrushPicker.indexBuilding = false
        BetterBrushPicker.indexReady = false
        BetterBrushPicker.indexState.error = "B42 did not return usable tile IDs through IsoWorld:getAllTiles(filename)"
        log("ERROR: direct tile enumeration returned zero usable IDs. Scan stopped; no empty caches were intentionally generated.")
        return
    end

    if #BetterBrushPicker.tilesets == 0 then
        BetterBrushPicker.indexReady = true
        BetterBrushPicker.indexBuilding = false
        BetterBrushPicker.indexState.cached = #allTilesets
        BetterBrushPicker.indexState.totalTilesets = #allTilesets
        log(string.format("All %d tilesets loaded from persistent cache.", #allTilesets))
        if BrushToolChooseTileUI ~= nil and BrushToolChooseTileUI.instance ~= nil then
            BrushToolChooseTileUI.instance:refreshResults()
        end
        return
    end

    BetterBrushPicker.indexBuilding = true
    BetterBrushPicker.indexReady = false
    log(string.format("Direct index build/resume: %d tilesets remaining, %d actual tile IDs per burst.", #BetterBrushPicker.tilesets, TILES_PER_BURST))

    if (BetterBrushPicker.indexState.failedDefinitions or 0) > 0 then
        log(string.format("WARNING: %d definition lists could not be enumerated and were skipped; no empty cache was written for them.", BetterBrushPicker.indexState.failedDefinitions))
    end
end

function BetterBrushPicker.tickIndexBuild()
    local state = BetterBrushPicker.indexState
    if not BetterBrushPicker.indexBuilding or state == nil then return end

    local budget = TILES_PER_BURST
    while budget > 0 and state.tilesetIndex <= #BetterBrushPicker.tilesets do
        local entry = BetterBrushPicker.tilesets[state.tilesetIndex]
        local tileset = entry.tileset
        local tileList = entry.tiles
        local tileCount = entry.count or 0

        if tileList == nil or state.tileIndex >= tileCount then
            local rows = {}
            local prefix = tileset .. "_"
            for i = #BetterBrushPicker.index, 1, -1 do
                local result = BetterBrushPicker.index[i]
                if string.sub(result.id, 1, #prefix) == prefix then
                    table.insert(rows, 1, result)
                else
                    break
                end
            end

            if writeCacheFile(tileset, entry.filename, rows) then
                state.cached = (state.cached or 0) + 1
                debugLog(string.format("Cached tileset %s (%s): %d tiles.", tileset, tostring(entry.filename or ""), #rows))
            else
                log("WARNING: could not write cache for " .. tostring(entry.filename or tileset))
            end

            if tileCount == 0 then
                log("WARNING: no direct tile IDs reported for " .. tileset)
            end

            state.tileIndex = 0
            state.tilesetIndex = state.tilesetIndex + 1
            -- Yield after each completed tileset.
            break
        end

        local ok, tileName = pcall(function()
            return tostring(tileList:get(state.tileIndex))
        end)
        state.tileIndex = state.tileIndex + 1
        state.checked = state.checked + 1
        budget = budget - 1

        if ok and tileName ~= nil and tileName ~= "nil" and tileName ~= "" and isBrushTileId(tileName) then
            local category = categoryFor(tileset)
            local result = {
                id = tileName,
                name = tileName,
                tileset = tileset,
                category = category,
                parent = "",
                spriteType = "",
                searchText = buildSearchText(tileName, tileset, category, "", ""),
            }
            table.insert(BetterBrushPicker.index, result)
            BetterBrushPicker.indexById[tileName] = result
            state.added = state.added + 1
        end
    end

    if state.tilesetIndex > #BetterBrushPicker.tilesets then
        finishIndex()
    end
end

BetterBrushPickerTileGrid = nil

local function diagnosticGridState(grid, label, firstRow, lastRow)
    if not BetterBrushPicker.DIAGNOSTIC or grid == nil then return end

    local width = tonumber(grid.width) or -1
    local height = tonumber(grid.height) or -1
    local x = tonumber(grid.x) or -1
    local y = tonumber(grid.y) or -1
    local absX, absY = -1, -1
    pcall(function() absX = tonumber(grid:getAbsoluteX()) or -1 end)
    pcall(function() absY = tonumber(grid:getAbsoluteY()) or -1 end)

    local scrollHeight = -1
    local yScroll = -1
    pcall(function() scrollHeight = tonumber(grid:getScrollHeight()) or -1 end)
    pcall(function() yScroll = tonumber(grid:getYScroll()) or -1 end)

    local vVisible = false
    pcall(function() vVisible = grid:isVScrollBarVisible() == true end)

    local vX, vY, vW, vH = -1, -1, -1, -1
    if grid.vscroll ~= nil then
        vX = tonumber(grid.vscroll.x) or -1
        vY = tonumber(grid.vscroll.y) or -1
        pcall(function() vW = tonumber(grid.vscroll.width) or vW end)
        pcall(function() vH = tonumber(grid.vscroll:getHeight()) or vH end)
    end

    local javaW, javaH = -1, -1
    if grid.javaObject ~= nil then
        pcall(function() javaW = tonumber(grid.javaObject:getWidth()) or -1 end)
        pcall(function() javaH = tonumber(grid.javaObject:getHeight()) or -1 end)
    end

    local parentW, parentH, parentX, parentY = -1, -1, -1, -1
    if grid.parent ~= nil then
        parentW = tonumber(grid.parent.width) or -1
        parentH = tonumber(grid.parent.height) or -1
        parentX = tonumber(grid.parent.x) or -1
        parentY = tonumber(grid.parent.y) or -1
    end

    local totalRows = math.ceil(#(grid.results or {}) / math.max(1, tonumber(grid.columns) or 1))
    local maxScroll = math.max(0, scrollHeight - height)
    local signature = table.concat({
        tostring(label or ""),
        tostring(width), tostring(height), tostring(x), tostring(y),
        tostring(absX), tostring(absY), tostring(javaW), tostring(javaH),
        tostring(#(grid.results or {})), tostring(grid.columns or -1), tostring(totalRows),
        tostring(grid.contentHeight or -1), tostring(scrollHeight), tostring(yScroll),
        tostring(maxScroll), tostring(vVisible), tostring(vX), tostring(vY), tostring(vW), tostring(vH),
        tostring(parentW), tostring(parentH), tostring(parentX), tostring(parentY),
        tostring(firstRow or -1), tostring(lastRow or -1)
    }, "|")

    if grid._bbpDiagnosticLast ~= signature then
        grid._bbpDiagnosticLast = signature
        diagnosticLog(string.format(
            "%s | grid=%dx%d at(%d,%d) abs(%d,%d) java=%dx%d | results=%d cols=%d rows=%d content=%d scrollH=%d yScroll=%d maxScroll=%d | vscroll=%s x=%d y=%d w=%d h=%d | parent=%dx%d at(%d,%d) | visibleRows=%d..%d",
            tostring(label or "state"),
            width, height, x, y, absX, absY, javaW, javaH,
            #(grid.results or {}), tonumber(grid.columns) or -1, totalRows, tonumber(grid.contentHeight) or -1,
            scrollHeight, yScroll, maxScroll, tostring(vVisible), vX, vY, vW, vH,
            parentW, parentH, parentX, parentY, firstRow or -1, lastRow or -1
        ))
    end
end

function BetterBrushPicker.validateTileForBrush(tileName)
    local spriteName = tostring(tileName or "")
    if spriteName == "" then
        return false, "empty tile ID", nil
    end

    local tileIndex = tonumber(spriteName:match("_(%d+)$"))
    if tileIndex == nil or tileIndex < 0 or tileIndex > 2047 then
        return false, "tile ID is outside the vanilla brush atlas range", nil
    end

    local texture = resolveTileTexture(spriteName)
    if texture == nil then
        return false, "tile has no resolvable texture", nil
    end

    local spriteOk, sprite = pcall(function() return getSprite(spriteName) end)
    if not spriteOk or sprite == nil then
        return false, "tile has no sprite", nil
    end

    return true, nil, sprite
end

function BetterBrushPicker.selectTile(result, character, owner)
    if result == nil then
        return false
    end

    local spriteName = tostring(result.id or "")
    local valid, reason, sprite = BetterBrushPicker.validateTileForBrush(spriteName)
    if not valid then
        log("Refusing tile " .. spriteName .. ": " .. tostring(reason))
        return false
    end

    character = character or getPlayer()
    if character == nil then
        log("Refusing tile selection because no player character is available.")
        return false
    end

    local playerOk, playerNum = pcall(function() return character:getPlayerNum() end)
    if not playerOk or playerNum == nil then
        log("Could not determine player number for tile: " .. spriteName)
        return false
    end

    local cursorOk, cursor = pcall(function()
        return ISBrushToolTileCursor:new(spriteName, spriteName, character)
    end)
    if not cursorOk or cursor == nil then
        log("Cursor creation failed for tile: " .. spriteName)
        return false
    end

    local dragOk = pcall(function()
        getCell():setDrag(cursor, playerNum)
    end)
    if not dragOk then
        log("Failed to activate brush cursor for tile: " .. spriteName)
        return false
    end

    BetterBrushPicker.addRecent(spriteName)

    if owner ~= nil then
        owner.selectedTileName = spriteName
        owner.selectedResult = result
    end

    return true
end

function BetterBrushPicker.buildSearchResults(searchText, category, viewMode)
    local tokens = splitSearch(searchText or "")
    local results = {}
    category = category or "All"
    viewMode = viewMode or "All"
    loadUserState()

    local function addIfMatch(result)
        if result == nil then return end
        if category ~= "All" and result.category ~= category then return end
        if matchesTokens(result.searchText, tokens) then
            table.insert(results, result)
        end
    end

    if viewMode == "Favorites" then
        for i = 1, #BetterBrushPicker.favoriteOrder do
            local result = BetterBrushPicker.indexById[BetterBrushPicker.favoriteOrder[i]]
            addIfMatch(result)
        end
    elseif viewMode == "Recent" then
        for i = 1, #BetterBrushPicker.recentOrder do
            local result = BetterBrushPicker.indexById[BetterBrushPicker.recentOrder[i]]
            addIfMatch(result)
        end
    else
        for i = 1, #BetterBrushPicker.index do
            addIfMatch(BetterBrushPicker.index[i])
        end
    end

    return results
end

local function install()
    if BetterBrushPicker.installed then return end
    if BrushToolChooseTileUI == nil or BrushToolTilePickerList == nil or ISBrushToolTileCursor == nil then
        return false
    end

    BetterBrushPicker.installed = true

    BetterBrushPickerTileGrid = ISPanel:derive("BetterBrushPickerTileGrid")

    -- Layout values are deliberately kept separate from the indexing code.
    -- The card rectangle is the same rectangle used for mouse hit-testing.
    local GRID_MARGIN = 8
    local CARD_WIDTH = 148
    local CARD_HEIGHT = 160
    local CARD_GAP = 8
    local ROW_HEIGHT = CARD_HEIGHT + CARD_GAP
    local PREVIEW_HEIGHT = 106
    local LABEL_GAP = 8

    local function trimTextToWidth(text, font, maxWidth)
        text = tostring(text or "")
        if getTextManager():MeasureStringX(font, text) <= maxWidth then
            return text
        end

        local suffix = "..."
        local length = #text
        while length > 0 do
            local candidate = string.sub(text, 1, length) .. suffix
            if getTextManager():MeasureStringX(font, candidate) <= maxWidth then
                return candidate
            end
            length = length - 1
        end
        return suffix
    end

    function BetterBrushPickerTileGrid:new(x, y, w, h, character, owner)
        local o = ISPanel.new(self, x, y, w, h)
        o.backgroundColor = {r=0, g=0, b=0, a=0.0}
        o.owner = owner
        o.results = {}
        o.columns = math.max(1, math.floor((w - GRID_MARGIN * 2 + CARD_GAP) / (CARD_WIDTH + CARD_GAP)))
        o.rowHeight = ROW_HEIGHT
        o.mouseOverIndex = nil
        return o
    end

    function BetterBrushPickerTileGrid:recalculateColumns()
        self.columns = math.max(1, math.floor((self.width - GRID_MARGIN * 2 + CARD_GAP) / (CARD_WIDTH + CARD_GAP)))
    end

    function BetterBrushPickerTileGrid:setResults(results)
        self.results = results or {}
        self.posToTileNameTable = {}
        self:recalculateColumns()
        local rows = math.ceil(#self.results / self.columns)
        local contentHeight = GRID_MARGIN * 2 + math.max(0, rows * ROW_HEIGHT - CARD_GAP)
        self.contentHeight = contentHeight

        -- BrushToolTilePickerList has its own inherited list-box clipping state.
        -- Keep its scrollbar support, but make the clip area match our actual
        -- tile viewport instead of the vanilla picker dimensions.
        self.scrollAreaHeight = self.height
        self:setScrollHeight(math.max(self.height, contentHeight))
        pcall(function() self:updateScrollbars() end)
        local maxScroll = math.max(0, self:getScrollHeight() - self.height)
        self:setYScroll(math.max(-maxScroll, math.min(0, self:getYScroll())))
        self.mouseOverIndex = nil
        diagnosticGridState(self, "setResults")
    end

    function BetterBrushPickerTileGrid:prerender()
        -- Override the vanilla Brush Tool list's prerender so its inherited
        -- stencil cannot clip the custom grid after a small fixed number of rows.
        self.scrollAreaHeight = self.height

        local stencilX = 0
        local stencilY = 0
        local stencilW = self.width
        local stencilH = self.height

        if self.vscroll and self.vscroll:getHeight() < self:getScrollHeight() then
            stencilW = math.max(0, self.vscroll.x + 3)
        end

        self:setStencilRect(stencilX, stencilY, stencilW, stencilH)
        diagnosticGridState(self, string.format("prerender stencil=%dx%d", stencilW, stencilH))
        ISPanel.prerender(self)
    end

    function BetterBrushPickerTileGrid:render()
        ISPanel.render(self)

        self:recalculateColumns()

        local columns = math.max(1, self.columns)
        local rowHeight = self.rowHeight
        local totalRows = math.ceil(#self.results / columns)
        if totalRows <= 0 then return end

        local maxScroll = math.max(0, self:getScrollHeight() - self.height)
        local scrollY = math.max(-maxScroll, math.min(0, self:getYScroll()))
        if scrollY ~= self:getYScroll() then
            self:setYScroll(scrollY)
        end

        -- Only calculate rows that can actually intersect the viewport.
        -- Two extra rows avoid visible pop-in during fast wheel movement.
        local firstRow = math.max(0, math.floor((-scrollY - GRID_MARGIN - CARD_HEIGHT) / rowHeight) - 1)
        local lastRow = math.min(totalRows - 1, math.floor((self.height - scrollY - GRID_MARGIN) / rowHeight) + 1)

        diagnosticGridState(self, "render", firstRow, lastRow)

        for row = firstRow, lastRow do
            for col = 0, columns - 1 do
                local index = row * columns + col + 1
                local result = self.results[index]
                if result ~= nil then
                    local x = GRID_MARGIN + col * (CARD_WIDTH + CARD_GAP)
                    local y = GRID_MARGIN + row * rowHeight + scrollY
                    local hovered = self.mouseOverIndex == index

                    -- Card background/border. The tile preview and the click
                    -- target stay inside this exact rectangle.
                    self:drawRect(x, y, CARD_WIDTH, CARD_HEIGHT, 0.35, 0.08, 0.08, 0.08)
                    if hovered then
                        self:drawRectBorder(x, y, CARD_WIDTH, CARD_HEIGHT, 1.0, 1.0, 1.0, 1.0)
                    else
                        self:drawRectBorder(x, y, CARD_WIDTH, CARD_HEIGHT, 0.9, 0.9, 0.9, 0.9)
                    end

                    if BetterBrushPicker.isFavorite(result.id) then
                        self:drawRect(x + CARD_WIDTH - 30, y + 4, 25, 22, 0.75, 0.12, 0.12, 0.12)
                        self:drawTextCentre("F", x + CARD_WIDTH - 17.5, y + 6, 1, 1, 1, 0.95, UIFont.Small)
                    end

                    local previewX = x + 7
                    local previewY = y + 7
                    local previewW = CARD_WIDTH - 14
                    local previewH = PREVIEW_HEIGHT

                    self:drawRect(previewX, previewY, previewW, previewH, 0.25, 0.02, 0.02, 0.02)
                    -- A bright outline keeps the preview area readable even when the
                    -- tile texture itself is dark or the texture lookup is pending.
                    self:drawRectBorder(previewX, previewY, previewW, previewH, 0.95, 1.0, 1.0, 1.0)

                    local texture = resolveTileTexture(result.id)
                    if texture ~= nil then
                        local tw = texture:getWidth()
                        local th = texture:getHeight()
                        if tw > 0 and th > 0 then
                            local scale = math.min(previewW / tw, previewH / th)
                            local drawW = tw * scale
                            local drawH = th * scale
                            local offsetX = 0
                            local offsetY = 0

                            local offsetOk, ox, oy = pcall(function()
                                return texture:getOffsetX(), texture:getOffsetY()
                            end)
                            if offsetOk then
                                offsetX = tonumber(ox) or 0
                                offsetY = tonumber(oy) or 0
                            end

                            local drawX = previewX + (previewW - drawW) / 2 + offsetX * scale
                            local drawY = previewY + (previewH - drawH) / 2 + offsetY * scale

                            -- Keep unusual texture offsets from visually escaping
                            -- the preview box and overlapping a neighboring card.
                            drawX = math.max(previewX, math.min(drawX, previewX + previewW - drawW))
                            drawY = math.max(previewY, math.min(drawY, previewY + previewH - drawH))

                            self:drawTextureScaled(texture, drawX, drawY, drawW, drawH, 1, 1, 1, 1)
                        end
                    end

                    local labelY = previewY + previewH + LABEL_GAP
                    local label = trimTextToWidth(result.id, UIFont.Small, CARD_WIDTH - 16)
                    self:drawTextCentre(
                        label,
                        x + CARD_WIDTH / 2,
                        labelY,
                        1, 1, 1, 0.95,
                        UIFont.Small
                    )

                    local tilesetLabel = trimTextToWidth(result.tileset, UIFont.Small, CARD_WIDTH - 16)
                    self:drawTextCentre(
                        tilesetLabel,
                        x + CARD_WIDTH / 2,
                        labelY + 17,
                        0.75, 0.75, 0.75, 0.8,
                        UIFont.Small
                    )
                end
            end
        end

        -- Release our tile-grid stencil before the rest of the UI is rendered.
        self:clearStencilRect()
    end

    function BetterBrushPickerTileGrid:getResultAt(x, y)
        local columns = math.max(1, self.columns)
        local contentY = y - self:getYScroll()
        local relativeX = x - GRID_MARGIN
        local relativeY = contentY - GRID_MARGIN
        if relativeX < 0 or relativeY < 0 then return nil, nil end

        local col = math.floor(relativeX / (CARD_WIDTH + CARD_GAP))
        local row = math.floor(relativeY / ROW_HEIGHT)
        if col < 0 or col >= columns or row < 0 then return nil, nil end

        local cardX = GRID_MARGIN + col * (CARD_WIDTH + CARD_GAP)
        local cardY = GRID_MARGIN + row * ROW_HEIGHT
        if x < cardX or x > cardX + CARD_WIDTH or contentY < cardY or contentY > cardY + CARD_HEIGHT then
            return nil, nil
        end

        local index = row * columns + col + 1
        return self.results[index], index, cardX, cardY
    end

    function BetterBrushPickerTileGrid:onMouseMove(x, y)
        local _, index = self:getResultAt(x, y)
        self.mouseOverIndex = index
        return true
    end

    function BetterBrushPickerTileGrid:onMouseMoveOutside(x, y)
        self.mouseOverIndex = nil
        return true
    end

    function BetterBrushPickerTileGrid:onMouseDown(x, y)
        local result, _, cardX, cardY = self:getResultAt(x, y)
        if result == nil then return false end

        local favoriteX = cardX + CARD_WIDTH - 30
        local favoriteY = cardY + 4
        if x >= favoriteX and x <= cardX + CARD_WIDTH - 5 and y >= favoriteY and y <= favoriteY + 22 then
            return BetterBrushPicker.toggleFavorite(result.id)
        end

        return BetterBrushPicker.selectTile(result, self.character, self.owner)
    end

    function BetterBrushPickerTileGrid:onMouseWheel(del)
        local maxScroll = math.max(0, self:getScrollHeight() - self.height)
        local requested = self:getYScroll() - del * 128
        local clamped = math.max(-maxScroll, math.min(0, requested))
        self:setYScroll(clamped)
        diagnosticGridState(self, string.format("wheel del=%s req=%d", tostring(del), requested))
        return true
    end

    function BrushToolChooseTileUI.openPanel(x, y, playerObj)
        if y < 0 then y = 0 end
        if BrushToolChooseTileUI.instance == nil then
            local window = BrushToolChooseTileUI:new(x, y, 1220, 760, playerObj)
            window:initialise()
            window:addToUIManager()
            BrushToolChooseTileUI.instance = window
        end
    end

    function BrushToolChooseTileUI:createChildren()
        ISCollapsableWindow.createChildren(self)
        local th = self:titleBarHeight()
        local topY = th + 6

        self.searchEntryBox = ISTextEntryBox:new("", 8, topY, 420, 24)
        self.searchEntryBox.font = UIFont.Small
        self.searchEntryBox.onTextChange = BrushToolChooseTileUI.onTextChange
        self:addChild(self.searchEntryBox)

        local x = self.searchEntryBox:getRight() + 8
        for i = 1, #BetterBrushPicker.categories do
            local category = BetterBrushPicker.categories[i]
            local width = 70
            local button = ISButton:new(x, topY, width, 24, category, self, BrushToolChooseTileUI.onCategoryClick)
            button.internal = category
            button:initialise()
            button:instantiate()
            self:addChild(button)
            x = x + width + 3
        end

        local modeY = topY + 30
        self.viewModeButtons = {}
        local modeButtons = {
            { key = "All", title = "All Results", width = 100 },
            { key = "Favorites", title = "Favorites", width = 100 },
            { key = "Recent", title = "Recent", width = 100 },
        }
        local modeX = 8
        for i = 1, #modeButtons do
            local data = modeButtons[i]
            local button = ISButton:new(modeX, modeY, data.width, 24, data.title, self, BrushToolChooseTileUI.onViewModeClick)
            button.internal = data.key
            button:initialise()
            button:instantiate()
            self:addChild(button)
            self.viewModeButtons[data.key] = button
            modeX = modeX + data.width + 4
        end

        local contentTop = modeY + 30
        local bottomHeight = 46
        local tilesWidth = self.width - 16
        local tilesHeight = self.height - contentTop - bottomHeight

        self.tilesList = BetterBrushPickerTileGrid:new(8, contentTop, tilesWidth, tilesHeight, self.character, self)
        self.tilesList.anchorRight = true
        self.tilesList.anchorBottom = true
        self.tilesList:initialise()
        self.tilesList:instantiate()
        self.tilesList:addScrollBars()
        self:addChild(self.tilesList)

        self.selectedTileName = "No tile selected"
        self.selectedResult = nil

        loadUserState()
        BetterBrushPicker.startIndexBuild()
        self:refreshResults()
    end

    function BrushToolChooseTileUI:onTextChange()
        if BrushToolChooseTileUI.instance ~= nil then
            BrushToolChooseTileUI.instance.selectedResult = nil
            BrushToolChooseTileUI.instance:refreshResults()
        end
    end

    function BrushToolChooseTileUI:onCategoryClick(button)
        BetterBrushPicker.activeCategory = button.internal or "All"
        self.selectedResult = nil
        self:refreshResults()
    end

    function BrushToolChooseTileUI:onViewModeClick(button)
        BetterBrushPicker.viewMode = button.internal or "All"
        self.selectedResult = nil
        self:refreshResults()
    end

    function BrushToolChooseTileUI:refreshResults()
        if self.tilesList == nil then return end

        if not BetterBrushPicker.indexReady then
            self.tilesList:setResults({})
            self.selectedTileName = BetterBrushPicker.indexBuilding and "Indexing tiles..." or "Preparing index..."
            return
        end

        local searchText = self.searchEntryBox:getInternalText()
        BetterBrushPicker.lastSearch = searchText
        local category = BetterBrushPicker.activeCategory
        local results = BetterBrushPicker.buildSearchResults(searchText, category, BetterBrushPicker.viewMode)

        self.currentResults = results
        self.tilesList:setResults(results)

        if #results == 0 then
            self.selectedTileName = "No matching tiles"
        elseif self.selectedResult == nil then
            self.selectedTileName = "Results: " .. tostring(#results) .. " (click a tile)"
        end
    end

    function BrushToolChooseTileUI:render()
        ISCollapsableWindow.render(self)
        local footerY = self.height - 34
        self:drawText(
            "Selected: " .. tostring(self.selectedTileName or "None"),
            10, footerY, 1, 1, 1, 0.95, UIFont.Small
        )

        local state = BetterBrushPicker.indexState
        local progress = ""
        if BetterBrushPicker.indexReady and state ~= nil then
            progress = string.format("Indexed %d tiles", state.added)
        elseif BetterBrushPicker.indexBuilding and state ~= nil then
            progress = string.format("Indexing tiles: %d found / %d actual IDs processed", state.added, state.checked)
        else
            progress = "Starting tile index..."
        end
        self:drawTextRight(progress, self.width - 10, footerY, 1, 1, 1, 0.8, UIFont.Small)
    end

    function BrushToolChooseTileUI:close()
        BrushToolChooseTileUI.instance = nil
        self:setVisible(false)
        self:removeFromUIManager()
    end

    function BrushToolChooseTileUI:new(x, y, width, height, character)
        local o = ISCollapsableWindow.new(self, x, y, width, height)
        o:setResizable(true)
        o.title = "Better Brush Picker — Individual Tiles"
        o.character = character
        return o
    end

    local VERSION = "0.4.6"
    log("Installed v" .. VERSION .. " successfully.")
    log("Version marker: BetterBrushPicker source v" .. VERSION)
    return true
end

local function tick()
    if not BetterBrushPicker.installed then
        install()
    end
    if BetterBrushPicker.installed then
        BetterBrushPicker.tickTextureWarmup()
        BetterBrushPicker.tickIndexBuild()
    end
end

local function onGameBoot()
    install()
    Events.OnTick.Add(tick)
end

Events.OnGameBoot.Add(onGameBoot)
