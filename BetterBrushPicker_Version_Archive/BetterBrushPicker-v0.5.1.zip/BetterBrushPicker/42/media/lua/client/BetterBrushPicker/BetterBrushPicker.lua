-- Better Brush Picker
-- Build 42
-- Version 0.5.1
-- Author: Dizzy
--
-- v0.2.8 replaces the old fixed-slot probing scan with direct enumeration of the tiles exposed by IsoWorld:getAllTiles. Persistent per-definition-list caching is kept.
-- v0.2.9 avoids full-index and full-result sorting so completion does not block the game thread on ~61k entries.
-- v0.5.1 is a ground-up UI rebuild: the gallery uses native ISScrollingListBox rows.
-- The picker no longer requires the
-- user to choose a tilesheet before browsing results. Search results are
-- individual sprite/tile IDs and selection still uses the vanilla
-- ISBrushToolTileCursor.

local BetterBrushPicker = {}
BetterBrushPicker.installed = false
BetterBrushPicker.indexReady = false
BetterBrushPicker.indexBuilding = false
BetterBrushPicker.index = {}
BetterBrushPicker.tilesets = {}
BetterBrushPicker.activeCategory = "All"
BetterBrushPicker.lastSearch = ""
BetterBrushPicker.indexState = nil

-- Persistent cache and incremental work settings.
local CACHE_PREFIX = "BetterBrushPicker_tileset_"
local TILES_PER_BURST = 128

BetterBrushPicker.categories = {
    "All", "Furniture", "Walls", "Floors", "Decor", "Doors", "Windows", "Plants", "Roofs", "Other"
}

-- These aliases are deliberately broad. They supplement the actual sprite
-- and tileset names and will be refined in later versions with more exact
-- per-sprite semantic tagging.
BetterBrushPicker.aliases = {
    chair = "chair chairs seat seating stool bench furniture",
    couch = "couch sofa sofas loveseat seating furniture",
    sofa = "sofa sofas couch couches loveseat seating furniture",
    table = "table tables desk furniture",
    desk = "desk desks table furniture office",
    bed = "bed beds bedding furniture",
    dresser = "dresser dressers storage furniture",
    shelf = "shelf shelves shelving storage furniture",
    cabinet = "cabinet cabinets cupboard storage furniture",
    locker = "locker lockers storage",
    fridge = "fridge refrigerator refrigeration freezer appliance appliances",
    refrigerator = "fridge refrigerator refrigeration freezer appliance appliances",
    freezer = "fridge refrigerator refrigeration freezer appliance appliances",
    stove = "stove cooker oven cooking appliance appliances",
    oven = "oven stove cooker cooking appliance appliances",
    microwave = "microwave appliance appliances cooking",
    sink = "sink sinks bathroom plumbing fixture fixtures counter",
    toilet = "toilet toilets bathroom plumbing fixture fixtures",
    bathtub = "bathtub tub bathroom plumbing fixture fixtures",
    shower = "shower bathroom plumbing fixture fixtures",
    window = "window windows curtain curtains fixture fixtures",
    door = "door doors doorway frame gate fixture fixtures",
    wall = "wall walls brick wood stone clapboard fence fencing railing",
    floor = "floor floors ground street road sidewalk curb carpet wood tile stone gravel dirt grass",
    plant = "plant plants tree trees bush bushes flower flowers vine vines vegetation foliage",
    tree = "tree trees vegetation foliage",
    grass = "grass vegetation foliage floor",
    roof = "roof roofs snow roofcap",
    lamp = "lamp lighting light lights fixture fixtures",
    light = "lamp lighting light lights fixture fixtures",
    rug = "rug rugs carpet carpets floor",
    sign = "sign signs signage notice notices poster advertising",
}

local function lower(value)
    return string.lower(tostring(value or ""))
end

local function contains(text, needle)
    return string.find(lower(text), lower(needle), 1, true) ~= nil
end

local function categoryFor(name)
    local n = lower(name)
    if contains(n, "door") or contains(n, "gate") then return "Doors" end
    if contains(n, "window") then return "Windows" end
    if contains(n, "roof") then return "Roofs" end
    if contains(n, "floor") or contains(n, "street") or contains(n, "curb") or contains(n, "blend") then return "Floors" end
    if contains(n, "wall") or contains(n, "fenc") or contains(n, "rail") then return "Walls" end
    if contains(n, "furniture") or contains(n, "appliance") or contains(n, "seating") or contains(n, "shelving")
        or contains(n, "storage") or contains(n, "counter") or contains(n, "sink") or contains(n, "bathroom")
        or contains(n, "bedding") or contains(n, "table") or contains(n, "desks") then return "Furniture" end
    if contains(n, "tree") or contains(n, "bush") or contains(n, "flower") or contains(n, "plant")
        or contains(n, "vegetation") or contains(n, "foliage") then return "Plants" end
    if contains(n, "sign") or contains(n, "notice") or contains(n, "overlay") or contains(n, "graffiti")
        or contains(n, "grime") or contains(n, "trash") or contains(n, "junk") or contains(n, "lighting")
        or contains(n, "light") or contains(n, "curtain") or contains(n, "rug") then return "Decor" end
    return "Other"
end

local function tileBaseName(fullName)
    local s = tostring(fullName or "")
    local base = s:match("^([^%.]+)")
    return base or s
end

local function isBrushTileId(tileName)
    local s = tostring(tileName or "")
    if s == "" then return false end
    local numericIndex = tonumber(s:match("_(%d+)$"))
    if numericIndex == nil then return false end
    return numericIndex >= 0 and numericIndex <= 2047
end

local function splitSearch(text)
    local tokens = {}
    for token in lower(text):gmatch("%S+") do
        table.insert(tokens, token)
    end
    return tokens
end

local function matchesTokens(searchText, tokens)
    if #tokens == 0 then return true end

    local text = lower(searchText)
    for i = 1, #tokens do
        local token = lower(tokens[i])
        local matched = string.find(text, token, 1, true) ~= nil

        if not matched then
            local aliasText = BetterBrushPicker.aliases[token]
            if aliasText ~= nil then
                for aliasToken in lower(aliasText):gmatch("%S+") do
                    if string.find(text, aliasToken, 1, true) ~= nil then
                        matched = true
                        break
                    end
                end
            end
        end

        if not matched then return false end
    end

    return true
end

local function buildSearchText(tileName, tilesetName, category, parent, spriteType)
    local text = lower(tostring(tileName or "") .. " " .. tostring(tilesetName or "") .. " " .. tostring(category or "") .. " " .. tostring(parent or "") .. " " .. tostring(spriteType or ""))

    -- Add semantic aliases based on the actual tileset name. These aliases
    -- improve searches such as "chair", "fridge", and "window" while each
    -- result remains the individual tile ID.
    local n = lower(tilesetName)
    if contains(n, "seating") then text = text .. " chair chairs seat seating stool bench couch sofa loveseat " end
    if contains(n, "bedding") then text = text .. " bed beds mattress bedding " end
    if contains(n, "refriger") then text = text .. " fridge refrigerator freezer appliance " end
    if contains(n, "cooking") then text = text .. " stove oven cooker microwave cooking appliance " end
    if contains(n, "bathroom") then text = text .. " toilet sink bathtub tub shower bathroom plumbing fixture " end
    if contains(n, "windows") then text = text .. " window windows curtain curtains " end
    if contains(n, "doors") then text = text .. " door doors doorway frame gate " end
    if contains(n, "tables") then text = text .. " table tables desk " end
    if contains(n, "shelving") then text = text .. " shelf shelves shelving storage " end
    if contains(n, "storage") then text = text .. " cabinet cupboard locker storage " end
    if contains(n, "lighting") then text = text .. " lamp light lighting fixture " end
    if contains(n, "plants") or contains(n, "vegetation") then text = text .. " plant tree bush flower vine vegetation foliage " end

    return text
end

local function uniqueTilesets()
    local result = {}
    local seen = {}
    local world = getWorld()

    -- Prefer the same definition-name list used by B42's direct tile API.
    local namesOk, names = pcall(function() return world:getAllTilesName() end)
    if namesOk and names ~= nil then
        for i = 0, names:size() - 1 do
            local imageName = tostring(names:get(i))
            local base = imageName:match("^([^%.]+)") or imageName
            if base ~= "" and not seen[base] then
                seen[base] = true
                table.insert(result, base)
            end
        end
    end

    -- Fallback only if the direct definition-name API returns nothing.
    if #result == 0 then
        local images = world:getTileImageNames()
        if images == nil then return result end
        for i = 0, images:size() - 1 do
            local imageName = tostring(images:get(i))
            local base = imageName:match("^([^%.]+)") or imageName
            if base ~= "" and not seen[base] then
                seen[base] = true
                table.insert(result, base)
            end
        end
    end

    table.sort(result)
    return result
end

-- Build a direct queue from B42's actual tile-definition lists.
-- IMPORTANT: getAllTiles() returns a Java HashMap, but its keySet()/iterator()
-- methods are not exposed to Kahlua reliably in the target B42 build. The
-- public getAllTilesName() + getAllTiles(filename) route is safer here.
local function getTileDefinitionNames(world)
    local ok, names = pcall(function() return world:getAllTilesName() end)
    if not ok or names == nil then
        return nil, "IsoWorld:getAllTilesName() failed"
    end
    local sizeOk, size = pcall(function() return names:size() end)
    if not sizeOk or size == nil then
        return nil, "IsoWorld:getAllTilesName() returned an unusable list"
    end
    return names, nil
end

local function buildDirectTileLookup()
    local world = getWorld()
    local names, namesError = getTileDefinitionNames(world)
    if names == nil then
        print("[BetterBrushPicker] ERROR: " .. tostring(namesError))
        return nil, 0, 0
    end

    local queue = {}
    local seen = {}
    local totalDirectIds = 0
    local failedSets = 0
    local definitionCount = names:size()

    for i = 0, definitionCount - 1 do
        local nameOk, filename = pcall(function() return tostring(names:get(i)) end)
        if nameOk and filename ~= nil and filename ~= "" and filename ~= "nil" then
            -- Keep the exact filename returned by B42. Do not strip its
            -- extension before calling getAllTiles(filename).
            local tileset = tileBaseName(filename)
            if tileset ~= "" and not seen[tileset] then
                local listOk, tileList = pcall(function()
                    return world:getAllTiles(filename)
                end)

                -- Defensive fallback for builds where the list is keyed by
                -- the base name rather than the definition filename.
                if (not listOk or tileList == nil) and tileset ~= filename then
                    listOk, tileList = pcall(function()
                        return world:getAllTiles(tileset)
                    end)
                end

                local count = 0
                if listOk and tileList ~= nil then
                    local sizeOk, size = pcall(function() return tileList:size() end)
                    if sizeOk and size ~= nil then
                        count = size
                    else
                        listOk = false
                    end
                end

                seen[tileset] = true
                if listOk and tileList ~= nil then
                    table.insert(queue, {
                        tileset = tileset,
                        filename = filename,
                        tiles = tileList,
                        count = count,
                    })
                    totalDirectIds = totalDirectIds + count
                else
                    failedSets = failedSets + 1
                    print(string.format("[BetterBrushPicker] WARNING: could not enumerate tile IDs for %s", filename))
                end
            end
        end
    end

    print(string.format(
        "[BetterBrushPicker] Direct tile enumeration found %d actual tile IDs across %d tilesets (%d definition lists failed).",
        totalDirectIds, #queue, failedSets
    ))
    return queue, totalDirectIds, failedSets
end

local function sanitizeFilePart(value)
    local s = tostring(value or "")
    s = s:gsub("[^%w%._%-]", "_")
    if s == "" then s = "unknown" end
    return s
end

local function cacheFileFor(definitionFilename)
    return CACHE_PREFIX .. sanitizeFilePart(definitionFilename) .. ".txt"
end

local function writeLine(writer, value)
    writer:write(tostring(value or "") .. "\n")
end

local function readCacheFile(fileName)
    local reader = getFileReader(fileName, false)
    if not reader then return nil end

    local rows = {}
    local line = reader:readLine()
    if line ~= "BBP_CACHE_7" then
        reader:close()
        return nil
    end

    line = reader:readLine()
    while line ~= nil do
        if line == "END" then
            reader:close()
            return rows
        end
        local id, tileset, category = line:match("^([^|]*)|([^|]*)|([^|]*)$")
        if id and tileset and category and isBrushTileId(id) then
            table.insert(rows, {
                id = id,
                name = id,
                tileset = tileset,
                category = category,
                parent = "",
                spriteType = "",
                searchText = buildSearchText(id, tileset, category, "", ""),
            })
        else
            reader:close()
            return nil
        end
        line = reader:readLine()
    end

    reader:close()
    return nil
end

local function writeCacheFile(tileset, definitionFilename, rows)
    local fileName = cacheFileFor(definitionFilename or tileset)
    local writer = getFileWriter(fileName, true, false)
    if not writer then return false end

    writeLine(writer, "BBP_CACHE_7")
    for i = 1, #rows do
        local result = rows[i]
        writeLine(writer, result.id .. "|" .. result.tileset .. "|" .. result.category)
    end
    writeLine(writer, "END")
    writer:close()
    return true
end


local function loadExistingCacheSets(tilesetQueue, failedDefinitions)
    local loaded = {}
    local missing = {}
    local cachedSets = 0

    for i = 1, #tilesetQueue do
        local entry = tilesetQueue[i]
        local tileset = entry.tileset
        local rows = readCacheFile(cacheFileFor(entry.filename or tileset))
        if rows then
            for j = 1, #rows do table.insert(loaded, rows[j]) end
            cachedSets = cachedSets + 1
        else
            table.insert(missing, entry)
        end
    end

    BetterBrushPicker.index = loaded
    BetterBrushPicker.tilesets = missing
    BetterBrushPicker.indexState = {
        tilesetIndex = 1,
        tileIndex = 0,
        added = #loaded,
        checked = 0,
        cached = cachedSets,
        totalTilesets = #tilesetQueue,
        totalActualTiles = 0,
        missingTilesets = 0,
        failedDefinitions = failedDefinitions or 0,
    }

    for i = 1, #missing do
        local count = missing[i].count or 0
        BetterBrushPicker.indexState.totalActualTiles = BetterBrushPicker.indexState.totalActualTiles + count
        if count == 0 then BetterBrushPicker.indexState.missingTilesets = BetterBrushPicker.indexState.missingTilesets + 1 end
    end

    if cachedSets > 0 then
        print(string.format("[BetterBrushPicker] Loaded %d cached tilesets (%d tiles); %d tilesets remain for direct enumeration.", cachedSets, #loaded, #missing))
    end

    return cachedSets > 0 or #missing == 0
end

local function finishIndex()
    local state = BetterBrushPicker.indexState
    BetterBrushPicker.indexBuilding = false
    BetterBrushPicker.indexReady = true
    print(string.format("[BetterBrushPicker] Full index ready: %d individual tiles checked=%d; cached sets=%d (no final global sort).",
        state and state.added or #BetterBrushPicker.index,
        state and state.checked or 0,
        state and state.cached or 0))

    if BrushToolChooseTileUI ~= nil and BrushToolChooseTileUI.instance ~= nil then
        BrushToolChooseTileUI.instance:refreshResults()
    end
end

function BetterBrushPicker.startIndexBuild()
    if BetterBrushPicker.indexBuilding or BetterBrushPicker.indexReady then return end

    local allTilesets = uniqueTilesets()
    local tileQueue, directTotal, failedSets = buildDirectTileLookup()
    BetterBrushPicker.index = {}
    BetterBrushPicker.tilesets = {}

    if tileQueue == nil then
        tileQueue = {}
    end

    loadExistingCacheSets(tileQueue, failedSets)

    if (#tileQueue == 0 or directTotal == 0) and #allTilesets > 0 then
        BetterBrushPicker.indexBuilding = false
        BetterBrushPicker.indexReady = false
        BetterBrushPicker.indexState.error = "B42 did not return usable tile IDs through IsoWorld:getAllTiles(filename)"
        print("[BetterBrushPicker] ERROR: direct tile enumeration returned zero usable IDs. Scan stopped; no empty caches were intentionally generated.")
        return
    end

    if #BetterBrushPicker.tilesets == 0 then
        BetterBrushPicker.indexReady = true
        BetterBrushPicker.indexBuilding = false
        BetterBrushPicker.indexState.cached = #allTilesets
        BetterBrushPicker.indexState.totalTilesets = #allTilesets
        print(string.format("[BetterBrushPicker] All %d tilesets loaded from persistent cache.", #allTilesets))
        return
    end

    BetterBrushPicker.indexBuilding = true
    BetterBrushPicker.indexReady = false
    print(string.format("[BetterBrushPicker] Direct index build/resume: %d tilesets remaining, %d actual tile IDs per burst.", #BetterBrushPicker.tilesets, TILES_PER_BURST))

    if (BetterBrushPicker.indexState.failedDefinitions or 0) > 0 then
        print(string.format("[BetterBrushPicker] WARNING: %d definition lists could not be enumerated and were skipped; no empty cache was written for them.", BetterBrushPicker.indexState.failedDefinitions))
    end
end

function BetterBrushPicker.tickIndexBuild()
    local state = BetterBrushPicker.indexState
    if not BetterBrushPicker.indexBuilding or state == nil then return end

    local budget = TILES_PER_BURST
    while budget > 0 and state.tilesetIndex <= #BetterBrushPicker.tilesets do
        local entry = BetterBrushPicker.tilesets[state.tilesetIndex]
        local tileset = entry.tileset
        local tileList = entry.tiles
        local tileCount = entry.count or 0

        if tileList == nil or state.tileIndex >= tileCount then
            local rows = {}
            local prefix = tileset .. "_"
            for i = #BetterBrushPicker.index, 1, -1 do
                local result = BetterBrushPicker.index[i]
                if string.sub(result.id, 1, #prefix) == prefix then
                    table.insert(rows, 1, result)
                else
                    break
                end
            end

            if writeCacheFile(tileset, entry.filename, rows) then
                state.cached = (state.cached or 0) + 1
                print(string.format("[BetterBrushPicker] Cached tileset %s (%s): %d tiles.", tileset, tostring(entry.filename or ""), #rows))
            else
                print("[BetterBrushPicker] WARNING: could not write cache for " .. tostring(entry.filename or tileset))
            end

            if tileCount == 0 then
                print("[BetterBrushPicker] WARNING: no direct tile IDs reported for " .. tileset)
            end

            state.tileIndex = 0
            state.tilesetIndex = state.tilesetIndex + 1
            -- Yield after each completed tileset.
            break
        end

        local ok, tileName = pcall(function()
            return tostring(tileList:get(state.tileIndex))
        end)
        state.tileIndex = state.tileIndex + 1
        state.checked = state.checked + 1
        budget = budget - 1

        if ok and tileName ~= nil and tileName ~= "nil" and tileName ~= "" and isBrushTileId(tileName) then
            local category = categoryFor(tileset)
            table.insert(BetterBrushPicker.index, {
                id = tileName,
                name = tileName,
                tileset = tileset,
                category = category,
                parent = "",
                spriteType = "",
                searchText = buildSearchText(tileName, tileset, category, "", ""),
            })
            state.added = state.added + 1
        end
    end

    if state.tilesetIndex > #BetterBrushPicker.tilesets then
        finishIndex()
    end
end

BetterBrushPickerTileRowList = ISScrollingListBox:derive("BetterBrushPickerTileRowList")

local TILE_COLUMNS = 8
local TILE_ROW_HEIGHT = 132
local TILE_GAP = 6

local function resolveTileTexture(tileName)
    local id = tostring(tileName or "")
    if id == "" then return nil end

    local ok, texture = pcall(function() return getTexture(id) end)
    if ok and texture ~= nil then
        return texture
    end

    -- B42 exposes explicit sprite-loading methods. Use them only for a
    -- visible tile when direct getTexture() did not already provide it.
    local spriteOk, sprite = pcall(function() return getSprite(id) end)
    if not spriteOk or sprite == nil then return nil end

    pcall(function() sprite:LoadFramesNoDirPageSimple(id) end)

    local directions = { IsoDirections.N, IsoDirections.NE, IsoDirections.E, IsoDirections.SE,
        IsoDirections.S, IsoDirections.SW, IsoDirections.W, IsoDirections.NW }
    for i = 1, #directions do
        local dir = directions[i]
        if dir ~= nil then
            local texOk, tex = pcall(function() return sprite:getTextureForFrame(0, dir) end)
            if texOk and tex ~= nil then return tex end
        end
    end

    return nil
end

local function drawTileCard(self, result, x, y, cardW, cardH, selected, hovered)
    local alpha = hovered and 1.0 or 0.85
    -- White outline makes dark/empty tile cards visible.
    self:drawRectBorder(x, y, cardW, cardH, alpha, 1, 1, 1)
    if selected then
        self:drawRectBorder(x + 1, y + 1, cardW - 2, cardH - 2, 1.0, 1, 1, 1)
    end

    local texture = resolveTileTexture(result.id)
    if texture ~= nil then
        local maxW = cardW - 12
        local maxH = 88
        local tw = texture:getWidth()
        local th = texture:getHeight()
        local scale = 1.0
        if tw > maxW then scale = maxW / tw end
        if th * scale > maxH then scale = maxH / th end
        local dw = tw * scale
        local dh = th * scale
        self:drawTextureScaled(texture,
            x + (cardW - dw) / 2,
            y + 4 + (maxH - dh) / 2,
            dw, dh, 1, 1, 1, 1)
    else
        self:drawTextCentre("?", x + cardW / 2, y + 34, 1, 1, 1, 0.9, UIFont.Large)
    end

    local label = tostring(result.id or "")
    self:drawTextCentre(label, x + cardW / 2, y + 96, 1, 1, 1, 0.95, UIFont.Small)
end

function BetterBrushPickerTileRowList:new(x, y, w, h, character, owner)
    local o = ISScrollingListBox.new(self, x, y, w, h)
    o.character = character
    o.owner = owner
    o.itemheight = TILE_ROW_HEIGHT
    o.drawBorder = true
    o.backgroundColor = {r=0, g=0, b=0, a=0.55}
    o.items = {}
    o.count = 0
    o.selected = -1
    o.mouseoverselected = -1
    o.doDrawItem = function(list, yy, item, alt)
        if (yy + list:getYScroll() + TILE_ROW_HEIGHT < 0) or (yy + list:getYScroll() >= list.height) then
            return yy + TILE_ROW_HEIGHT
        end

        local innerW = list.width - (list.vscroll and list.vscroll.width or 0)
        local cardW = math.floor((innerW - TILE_GAP * (TILE_COLUMNS + 1)) / TILE_COLUMNS)
        if cardW < 60 then cardW = 60 end

        for col = 1, TILE_COLUMNS do
            local result = item.item[col]
            if result ~= nil then
                local xx = TILE_GAP + (col - 1) * (cardW + TILE_GAP)
                local selected = list.owner ~= nil and list.owner.selectedResult == result
                local hovered = (list.mouseoverselected == item.index and list:isMouseOver()) and list.hoveredColumn == col
                drawTileCard(list, result, xx, yy + TILE_GAP, cardW, TILE_ROW_HEIGHT - TILE_GAP * 2, selected, hovered)
            end
        end
        return yy + TILE_ROW_HEIGHT
    end
    return o
end

function BetterBrushPickerTileRowList:setResults(results)
    self:clear()
    self.items = {}
    self.count = 0
    self.selected = -1

    local row = nil
    local col = 0
    for i = 1, #(results or {}) do
        if col == 0 then
            row = {}
            self:addItem("", row)
            col = 1
        else
            col = col + 1
        end
        row[col] = results[i]
        if col == TILE_COLUMNS then col = 0 end
    end

    self:setScrollHeight(math.max(self.height, #self.items * TILE_ROW_HEIGHT))
end

function BetterBrushPickerTileRowList:onMouseMove(dx, dy)
    if self:isMouseOverScrollBar() then
        self.hoveredColumn = nil
        return
    end
    self.mouseoverselected = self:rowAt(self:getMouseX(), self:getMouseY())
    local innerW = self.width - (self.vscroll and self.vscroll.width or 0)
    local cardW = math.floor((innerW - TILE_GAP * (TILE_COLUMNS + 1)) / TILE_COLUMNS)
    if cardW < 60 then cardW = 60 end
    local x = self:getMouseX() - TILE_GAP
    local col = math.floor(x / (cardW + TILE_GAP)) + 1
    if col >= 1 and col <= TILE_COLUMNS then
        self.hoveredColumn = col
    else
        self.hoveredColumn = nil
    end
end

function BetterBrushPickerTileRowList:onMouseMoveOutside(x, y)
    self.mouseoverselected = -1
    self.hoveredColumn = nil
end

function BetterBrushPickerTileRowList:onMouseDown(x, y)
    if #self.items == 0 then return end
    local rowIndex = self:rowAt(x, y)
    local rowItem = self.items[rowIndex]
    if rowIndex < 1 or rowItem == nil or rowItem.item == nil then return end

    local innerW = self.width - (self.vscroll and self.vscroll.width or 0)
    local cardW = math.floor((innerW - TILE_GAP * (TILE_COLUMNS + 1)) / TILE_COLUMNS)
    if cardW < 60 then cardW = 60 end
    local col = math.floor((x - TILE_GAP) / (cardW + TILE_GAP)) + 1
    if col < 1 or col > TILE_COLUMNS then return end

    local result = rowItem.item[col]
    if result == nil then return end

    self.selected = rowIndex
    if self.owner ~= nil then
        self.owner:selectTileResult(result)
    end
end

function BetterBrushPickerTileRowList:onMouseWheel(del)
    ISScrollingListBox.onMouseWheel(self, del)
    return true
end

local function install()
    if BetterBrushPicker.installed then return end
    if BrushToolChooseTileUI == nil or ISBrushToolTileCursor == nil or ISScrollingListBox == nil then
        return false
    end

    BetterBrushPicker.installed = true

    function BrushToolChooseTileUI.openPanel(x, y, playerObj)
        if y < 0 then y = 0 end
        if BrushToolChooseTileUI.instance == nil then
            local window = BrushToolChooseTileUI:new(x, y, 1180, 720, playerObj)
            window:initialise()
            window:addToUIManager()
            BrushToolChooseTileUI.instance = window
        end
    end

    function BrushToolChooseTileUI:createChildren()
        ISCollapsableWindow.createChildren(self)

        local th = self:titleBarHeight()
        self.selectedTileName = "No tile selected"
        self.selectedResult = nil

        self.searchEntryBox = ISTextEntryBox:new("", 10, th + 8, 450, 24)
        self.searchEntryBox.font = UIFont.Small
        self.searchEntryBox.onTextChange = BrushToolChooseTileUI.onTextChange
        self:addChild(self.searchEntryBox)

        local catY = th + 42
        local catX = 10
        local catW = 104
        for i = 1, #BetterBrushPicker.categories do
            local category = BetterBrushPicker.categories[i]
            local button = ISButton:new(catX, catY, catW, 24, category, self, BrushToolChooseTileUI.onCategoryClick)
            button.internal = category
            button:initialise()
            button:instantiate()
            self:addChild(button)
            catX = catX + catW + 5
        end

        local contentTop = catY + 32
        local footer = 42
        local tilesHeight = self.height - contentTop - footer

        self.tilesList = BetterBrushPickerTileRowList:new(10, contentTop, self.width - 20, tilesHeight, self.character, self)
        self.tilesList.anchorRight = true
        self.tilesList.anchorBottom = true
        self.tilesList:initialise()
        self.tilesList:instantiate()
        self.tilesList:addScrollBars()
        self:addChild(self.tilesList)

        BetterBrushPicker.startIndexBuild()
        self:refreshResults()
    end

    function BrushToolChooseTileUI:onTextChange()
        if BrushToolChooseTileUI.instance ~= nil then
            BrushToolChooseTileUI.instance.selectedResult = nil
            BrushToolChooseTileUI.instance:refreshResults()
        end
    end

    function BrushToolChooseTileUI:onCategoryClick(button)
        BetterBrushPicker.activeCategory = button.internal or "All"
        self.selectedResult = nil
        self:refreshResults()
    end

    function BrushToolChooseTileUI:refreshResults()
        if self.tilesList == nil then return end
        if not BetterBrushPicker.indexReady then
            self.tilesList:setResults({})
            self.selectedTileName = BetterBrushPicker.indexBuilding and "Indexing tiles..." or "Preparing index..."
            return
        end

        local searchText = self.searchEntryBox and self.searchEntryBox:getInternalText() or ""
        BetterBrushPicker.lastSearch = searchText
        local tokens = splitSearch(searchText)
        local category = BetterBrushPicker.activeCategory
        local results = {}

        for i = 1, #BetterBrushPicker.index do
            local result = BetterBrushPicker.index[i]
            if (category == "All" or result.category == category) and matchesTokens(result.searchText, tokens) then
                table.insert(results, result)
            end
        end

        self.currentResults = results
        self.tilesList:setResults(results)
        if #results == 0 then
            self.selectedTileName = "No matching tiles"
        else
            self.selectedTileName = "Results: " .. tostring(#results) .. " (click a tile)"
        end
    end

    function BrushToolChooseTileUI:selectTileResult(result)
        if result == nil then return end
        local spriteName = tostring(result.id or "")
        if spriteName == "" then return end

        local character = self.character or getPlayer()
        if character == nil then return end

        local numericIndex = tonumber(spriteName:match("_(%d+)$"))
        if numericIndex == nil or numericIndex < 0 or numericIndex > 2047 then
            print("[BetterBrushPicker] Refusing non-brush tile ID: " .. spriteName)
            return
        end

        local cursorOk, cursor = pcall(function()
            return ISBrushToolTileCursor:new(spriteName, spriteName, character)
        end)
        if not cursorOk or cursor == nil then
            print("[BetterBrushPicker] Cursor creation failed for tile: " .. spriteName)
            return
        end

        local numOk, playerNum = pcall(function() return character:getPlayerNum() end)
        if not numOk or playerNum == nil then return end

        local dragOk = pcall(function()
            getCell():setDrag(cursor, playerNum)
        end)
        if not dragOk then return end

        self.selectedResult = result
        self.selectedTileName = spriteName
    end

    function BrushToolChooseTileUI:render()
        ISCollapsableWindow.render(self)
        local footerY = self.height - 30
        self:drawText("Selected: " .. tostring(self.selectedTileName or "None"), 10, footerY, 1, 1, 1, 0.95, UIFont.Small)

        local state = BetterBrushPicker.indexState
        local progress
        if BetterBrushPicker.indexReady and state ~= nil then
            progress = string.format("Indexed %d tiles", state.added)
        elseif BetterBrushPicker.indexBuilding and state ~= nil then
            progress = string.format("Indexing: %d tiles", state.added)
        else
            progress = "Starting tile index..."
        end
        self:drawText(progress, self.width - 180, footerY, 1, 1, 1, 0.8, UIFont.Small)
    end

    function BrushToolChooseTileUI:close()
        BrushToolChooseTileUI.instance = nil
        self:setVisible(false)
        self:removeFromUIManager()
    end

    function BrushToolChooseTileUI:new(x, y, width, height, character)
        local o = ISCollapsableWindow.new(self, x, y, width, height)
        o:setResizable(true)
        o.title = "Better Brush Picker — Individual Tiles"
        o.character = character
        return o
    end

    print("[BetterBrushPicker] Installed v0.5.1 successfully.")
    print("[BetterBrushPicker] Ground-up UI: native ISScrollingListBox rows, 8 tiles per row, no custom stencil/scroll code.")
    return true
end

local function tick()
    if not BetterBrushPicker.installed then
        install()
    end
    if BetterBrushPicker.installed then
        BetterBrushPicker.tickIndexBuild()
    end
end

local function onGameBoot()
    install()
    Events.OnTick.Add(tick)
end

Events.OnGameBoot.Add(onGameBoot)
