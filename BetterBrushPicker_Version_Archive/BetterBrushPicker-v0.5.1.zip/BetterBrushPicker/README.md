# Better Brush Picker

Project Zomboid Build 42 mod by **Dizzy**.

v0.5.1 is a ground-up UI rebuild focused on reliable browsing of individual tile IDs.

### Core features
- Search individual tile IDs.
- Category filtering.
- Eight-tile visual rows.
- White tile-card outlines.
- Native Project Zomboid scrolling list.
- Vanilla brush cursor selection.
- Persistent indexed tile cache.

### Current architecture
The tile index continues to use B42's `IsoWorld:getAllTilesName()` / `getAllTiles(filename)` APIs. The UI is rebuilt around `ISScrollingListBox`, with each list item representing one row of eight tiles.

### Version marker
The game console should report:

```text
[BetterBrushPicker] Installed v0.5.1 successfully.
[BetterBrushPicker] Ground-up UI: native ISScrollingListBox rows, 8 tiles per row, no custom stencil/scroll code.
```
