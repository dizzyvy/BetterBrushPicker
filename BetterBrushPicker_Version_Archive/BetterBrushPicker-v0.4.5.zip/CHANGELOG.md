# Better Brush Picker 0.4.5

- Added bright white outlines around every tile card.
- Added a bright white outline around every tile preview area, including cards whose thumbnail is still missing.
- Changed hover/non-hover card borders to white/light-white for stronger separation.
- Added an explicit v0.4.5 startup version marker to make it easy to verify which source file the game loaded.

# Better Brush Picker 0.4.4

- Fixed tile thumbnail resolution across later tilesets.
- Thumbnail lookup now falls back through the loaded `IsoSprite` animation frame instead of relying only on `getTexture(tileId)`.
- Warmup now uses the first actual brush-compatible tile ID from each definition list rather than assuming every tileset has a usable `_0` entry.
- Indexing, persistent caches, search, Favorites/Recent, and vanilla brush-cursor selection remain unchanged.

## 0.4.4
- Added incremental tileset texture warmup using the same `getTexture(<tileset>_0)` access pattern used by the vanilla Brush Tool.
- Warmup runs a few tileset lookups per game tick instead of doing all texture work in one frame.
- Keeps the tile index/cache, visual grid layout, Favorites, Recent, search, and vanilla tile-cursor selection unchanged.
- Intended to fix later tilesets appearing as empty cards after direct tile enumeration.

## 0.4.2
- Decoupled the custom tile grid from vanilla BrushToolTilePickerList.
- Custom grid now derives directly from ISPanel to avoid inherited picker render/scroll state.
- Indexing, caching, search, Favorites, Recent, and vanilla cursor selection remain unchanged.

# Better Brush Picker changelog

## 0.4.1
- Diagnostic build for the persistent tile-grid clipping/black-area problem.
- Logs grid width/height/position, absolute and Java UI-element size, result count, columns/rows, content and scroll height, current scroll, maximum scroll, scrollbar geometry, parent geometry, stencil dimensions, and calculated visible rows.
- No indexing, cache format, search, Favorites/Recent, or tile-selection behavior intentionally changed.

# Better Brush Picker Changelog

## v0.4.0 — Favorites + Recent

- Added persistent Favorites and Recent tile lists.
- Added All Results, Favorites, and Recent view controls.
- Favorites are toggled from the small F marker on each tile card.
- Recent stores the 50 most recently selected tiles, newest first.
- Search and category filtering continue to apply inside Favorites and Recent.
- Added a lightweight `indexById` lookup so ordered Favorites/Recent views do not scan or sort the full 61k index.
- Added a separate user-state file; the existing `BBP_CACHE_7` tile cache format is unchanged.
- Fixed the install log version string so this build reports v0.4.0.

## v0.3.3 — Full Grid Viewport / Stencil Fix

- Fixed the custom tile grid being clipped by the inherited vanilla Brush Tool list stencil.
- The tile viewport now uses the full live height of the Better Brush Picker grid.
- Scrollbar width is still excluded from the drawing stencil when the scrollbar is active.
- No changes to tile indexing, persistent cache format, search, or vanilla brush cursor selection.

## v0.3.1 — UI and hitbox fixes

- Fixed tile cards and mouse hit-testing to use the same coordinate system while scrolling.
- Added visible spacing between cards so adjacent tiles cannot visually overlap.
- Added a bounded preview area for each tile and clamped unusual texture offsets to that area.
- Truncated long tile IDs and tileset names to the card width instead of letting text run into neighboring cards.
- Added a hover outline so the exact clickable card is obvious.
- Kept the v0.2.9 indexing/cache architecture and the v0.3.0 centralized tile-selection path unchanged.

## v0.3.0 — Reliability foundation

- Preserved the v0.2.9 direct tile-enumeration and persistent per-tileset cache architecture.
- Added centralized `validateTileForBrush()` validation for selectable tile IDs, textures, and sprites.
- Added centralized `selectTile()` handling for `ISBrushToolTileCursor` creation and `getCell():setDrag()`.
- Moved search-result construction into `BetterBrushPicker.buildSearchResults()`.
- Reset the selected result when search text or category changes.
- Refreshes the UI when all tilesets are loaded entirely from cache.
- Reduced routine cache logging; verbose cache messages now require `BetterBrushPicker.DEBUG = true`.
- Kept the v0.2.9 no-global-sort behavior and 128-ID scan burst.
- Cache format remains `BBP_CACHE_7`; no cache invalidation is required solely for this release.

## v0.2.9 — Performance baseline

- Reduced indexing burst size to 128 actual tile IDs per tick.
- Removed the final global sort of the full index.
- Removed the second full sort of the search results.
- Preserved persistent per-tileset caching.

## v0.2.8

- Tightened direct enumeration to Brush Tool-compatible numeric atlas IDs (0-2047).
- Added defensive validation before creating the vanilla brush cursor.
- Advanced the cache format for the stricter tile filter.

## Earlier builds

Earlier experimental builds are preserved in the historical archive under `versions/` so regressions can be traced to the exact source snapshot that introduced them.
