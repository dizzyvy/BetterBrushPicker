BETTER BRUSH PICKER v0.5.2
Author: Dizzy

This build is a ground-up rebuild of the picker UI.

Install the BetterBrushPicker folder into:
Zomboid/mods/

Build 42 is required.

v0.5.2 deliberately focuses on one thing: a reliable searchable tile picker.
The proven direct tile enumeration and persistent per-definition-list cache are retained from the last stable indexing build.

The gallery uses Project Zomboid's native ISScrollingListBox rather than the previous custom scrolling/stencil system.

On startup, the console should contain:
[BetterBrushPicker] Installed v0.5.2 successfully.
[BetterBrushPicker] Ground-up UI: native ISScrollingListBox rows, 8 tiles per row, no custom stencil/scroll code.
