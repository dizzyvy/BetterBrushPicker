## 0.5.2
- Improved thumbnail resolution using IsoSprite:LoadFrameExplicit() as the primary fallback.
- Added current-frame and frame-0 sprite fallbacks plus direct sprite.texture fallback.
- Added a bounded 512-entry thumbnail cache.
- Selection now uses the same thumbnail resolver, so tiles loaded by the fallback remain selectable.
- Added resolver statistics to the console for diagnosis.

# Better Brush Picker Changelog

## v0.5.1
- Ground-up UI rebuild from the stable v0.2.9 indexing base.
- Removed the previous custom tile-grid scrolling/stencil implementation.
- Uses Project Zomboid's native `ISScrollingListBox` for gallery rows and scrolling.
- Eight tiles per row with visible white card borders.
- Search and category filtering retained.
- Vanilla `ISBrushToolTileCursor` retained for placement.
- Removed the broken v0.5.0 `buildSearchResults` call.
- Removed the broken `IsoDirectionFrame:getTexture()` thumbnail path.
- Direct `getTexture(tileId)` remains the first thumbnail lookup; B42 sprite loading methods are a fallback for visible tiles only.
- Persistent tile enumeration/cache retained from v0.2.9.

## v0.5.0
- Experimental native-list rebuild; superseded by v0.5.1 after runtime testing exposed a missing search-results function.
